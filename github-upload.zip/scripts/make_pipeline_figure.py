#!/usr/bin/env python
"""Figure for the pipeline-validation study: EM by hop count and Dep_3, from saved runs."""
import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from gmrncm import metrics as M
runs = [0, 1, 2]
sys_ = [("ref_top5", "Flat + top-5", "#1f77b4"), ("ref_multihop5", "Flat + multihop-5", "#ff7f0e"),
        ("gmr_full", "GMR (full)", "#2ca02c"), ("gmr_norankinv", "GMR w/o rank-inv.", "#d62728")]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
for k, name, c in sys_:
    curves, deps = [], []
    for s in runs:
        rows = [json.loads(l) for l in open(f"results/runs/smoke_s{s}/predictions/{k}.jsonl")]
        rows = [r for r in rows if r["answerable"]]
        curves.append([np.mean([r["em"] for r in rows if r["num_hops"] == h] or [np.nan]) for h in (2, 3)])
        deps.append(json.load(open(f"results/runs/smoke_s{s}/topk_k3.json"))[k]["top3_dependence"])
    ax[0].plot(["2-hop", "3-hop"], np.nanmean(curves, 0), marker="o", label=name, color=c)
    ax[1].bar(name.replace(" ", "\n", 1), np.mean(deps), yerr=np.std(deps), color=c)
ax[0].set_ylabel("EM (answerable)"); ax[0].legend(fontsize=6); ax[0].tick_params(labelsize=7)
ax[1].set_ylabel("Dep$_3$"); ax[1].set_ylim(0.7, 1.0); ax[1].tick_params(axis="x", labelsize=6)
plt.tight_layout(); plt.savefig("paper/figures/pipeline_check.pdf"); plt.savefig("paper/figures/pipeline_check.png", dpi=160)
