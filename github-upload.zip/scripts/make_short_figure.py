"""Figure for the short paper: natural-distractor scaling (3 datasets) and MuSiQue by chain length. Needs results/real/*.json."""
import json, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
C = {"bm25": "#0072B2", "gmr": "#D55E00"}
plt.rcParams.update({"font.size": 7, "axes.spines.top": False, "axes.spines.right": False, "font.family": "serif"})
fig, ax = plt.subplots(1, 4, figsize=(7.0, 1.25), gridspec_kw={"width_ratios": [1, 1, 1, 1.05]})
own = json.load(open("results/real/recall_curves.json"))   # percent, k=1..10
summary = {}
for a, (d, nm) in zip(ax[:3], [("hotpotqa", "HotpotQA"), ("2wiki", "2Wiki"), ("musique", "MuSiQue")]):
    r = json.load(open(f"results/real/distractor_{d}.json")); n0 = r["own"]
    xs = [0] + [p["corpus"] - n0 for p in r["points"]]
    b = [own[d]["bm25"][4]] + [100 * p["bm25_R@5"] for p in r["points"]]
    g = [own[d]["gmr"][4]] + [100 * p["gmr_R@5"] for p in r["points"]]
    xk = [x / 1000 for x in xs]
    a.plot(xk, b, "--o", ms=3, lw=1.2, c=C["bm25"], label="BM25 (single step)"); a.plot(xk, g, "-s", ms=3, lw=1.2, c=C["gmr"], label="GMR-NCM retrieval")
    a.set_title(f"{nm} ({n0/1000:.1f}k own passages)", fontsize=7); a.set_xlabel("added distractor passages (k)"); a.grid(alpha=.25, lw=.4)
    summary[d] = {"added": xs, "bm25": b, "gmr": g}
ax[0].set_ylabel("Recall@5 (%)"); ax[1].legend(frameon=False, fontsize=6, loc="center")
bh = json.load(open("results/real/bench_musique.json"))["results"]["musique"]["retrieval"]["by_hops"]
hs = sorted(bh); x = np.arange(len(hs)); w = .36
ax[3].bar(x - w/2, [100 * bh[h]["bm25_R@5"] for h in hs], w, color=C["bm25"]); ax[3].bar(x + w/2, [100 * bh[h]["gmr_R@5"] for h in hs], w, color=C["gmr"])
ax[3].set_xticks(x); ax[3].set_xticklabels([f"{h}-hop\n(n={bh[h]['n']})" for h in hs]); ax[3].set_title("MuSiQue by chain length", fontsize=7); ax[3].set_ylabel("Recall@5 (%)")
plt.tight_layout(pad=0.3); plt.savefig("short/figures/fig_recall_real.pdf"); plt.savefig("short/figures/fig_recall_real.png", dpi=160)
json.dump(summary, open("results/real/distractor_summary.json", "w"), indent=1)
for d, v in summary.items(): print(d, v["added"], [round(x, 1) for x in v["bm25"]], [round(x, 1) for x in v["gmr"]])
