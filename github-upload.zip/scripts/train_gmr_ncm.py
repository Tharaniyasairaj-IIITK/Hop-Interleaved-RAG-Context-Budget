#!/usr/bin/env python
"""Train the reference GMR generator on precomputed traces (see docs/NCM_INTEGRATION.md for the official-NCM path)."""
import argparse, json, torch
from gmrncm.schema import load_examples, load_passages, read_jsonl
from gmrncm.pipeline import make_features
from gmrncm.model import GMRConceptGenerator, train

ap = argparse.ArgumentParser()
ap.add_argument("--train", required=True); ap.add_argument("--corpus", required=True); ap.add_argument("--traces", required=True)
ap.add_argument("--budget", type=int, default=5); ap.add_argument("--mode", default="multihop")
ap.add_argument("--epochs", type=int, default=10); ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--no_ground", action="store_true"); ap.add_argument("--no_rank_inv", action="store_true")
ap.add_argument("--out", default="artifacts/gmr_reference.pt")
a = ap.parse_args()
ex = load_examples(a.train); by_id = {p.passage_id: p for p in load_passages(a.corpus)}
traces = {t["id"]: t for t in read_jsonl(a.traces)}
feats = make_features(ex, traces, by_id, a.mode, a.budget)
m = GMRConceptGenerator(grounded=not a.no_ground)
train(m, feats, epochs=a.epochs, seed=a.seed, rank_invariance=not a.no_rank_inv)
torch.save(m.state_dict(), a.out)
