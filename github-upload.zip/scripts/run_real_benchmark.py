"""Real-data benchmark on the 1,000-question HotpotQA / 2Wiki / MuSiQue dev subsets (data/real, see download_real_data.sh).
Stage 1  retrieval:  Recall@k (k=2,5) of BM25 single-step vs. GMR-NCM hop-interleaved iterative retrieval, same index.
Stage 2  reading:    reference reader systems (flat top-5, flat multihop, GMR variants) trained on 60% / dev 10% / test 30%.
Outputs results/real_benchmark.json"""
import argparse, json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, "src")
from gmrncm.data.hippo import load_hippo_subset
from gmrncm.pipeline import build_traces, split, make_features, SPECS, topk_from_rows
from gmrncm.grounding import ground_context
from gmrncm import metrics as M, model as MD

ap = argparse.ArgumentParser()
ap.add_argument("--root", default="data/real"); ap.add_argument("--datasets", default="hotpotqa,2wiki,musique")
ap.add_argument("--limit", type=int, default=None); ap.add_argument("--seeds", default="0,1,2")
ap.add_argument("--epochs", type=int, default=5); ap.add_argument("--budget", type=int, default=5)
ap.add_argument("--out", default="results/real_benchmark.json"); ap.add_argument("--stage", default="all")
ap.add_argument("--only", default=None)
a = ap.parse_args()
MD.YESNO_CANDIDATES = True
SYS = ["closed_book", "ref_top5", "ref_multihop5", "gmr_noiter", "gmr_full"]


def recall_at(examples, traces, by_id, k, mode):
    r = []
    for e in examples:
        ctx = ground_context(traces[e.id], by_id, k, mode=mode)
        r.append(M.evidence_recall(e.gold_passage_titles, [p.title for p in ctx]))
    return float(np.mean(r))


def rrf_recall(examples, traces, by_id, k):
    r = []
    for e in examples:
        top = [by_id[c["passage_id"]].title for c in traces[e.id]["merged_candidates"][:k]]
        r.append(M.evidence_recall(e.gold_passage_titles, top))
    return float(np.mean(r))


def run_dataset(name):
    t0 = time.time()
    ex, corpus = load_hippo_subset(name, a.root, a.limit)
    tp = Path(f"results/real/traces_{name}{'' if not a.limit else '_'+str(a.limit)}.json")
    if tp.exists():
        traces = json.load(open(tp)); by_id = {p.passage_id: p for p in corpus}
    else:
        traces, by_id = build_traces(ex, corpus); tp.parent.mkdir(parents=True, exist_ok=True); json.dump(traces, open(tp, "w"))
    out = {"n": len(ex), "corpus": len(corpus), "trace_s": round(time.time() - t0, 1), "retrieval": {}, "reading": {}}
    for k in (2, 5):
        out["retrieval"][f"R@{k}"] = {"bm25_single": recall_at(ex, traces, by_id, k, "top_k"),
                                      "gmr_hop_interleaved": recall_at(ex, traces, by_id, k, "multihop"),
                                      "gmr_rrf_merged": rrf_recall(ex, traces, by_id, k)}
    by_hops = {}
    for h in sorted({e.num_hops for e in ex}):
        sub = [e for e in ex if e.num_hops == h]
        by_hops[str(h)] = {"n": len(sub), "bm25_R@5": recall_at(sub, traces, by_id, 5, "top_k"), "gmr_R@5": recall_at(sub, traces, by_id, 5, "multihop")}
    out["retrieval"]["by_hops"] = by_hops
    print(name, "retrieval", json.dumps(out["retrieval"]["R@5"]), flush=True)
    if a.stage == "retrieval":
        return name, out
    import torch
    from gmrncm.model import GMRConceptGenerator, train, featurize
    from gmrncm.baselines import MajorityPrior, NeuralPredictor
    from gmrncm.systems import evaluate_system
    from gmrncm.text import normalize_answer
    per_seed = {}
    for seed in [int(s) for s in a.seeds.split(",")]:
        tr, dv, te = split(ex, seed)
        torch.manual_seed(seed)
        # reader ceiling: answer is a mined candidate inside the (a) gold passages, (b) retrieved hop-interleaved context
        def ceiling(mode):
            ok = 0
            for e in te:
                ctx = [by_id[i] for i in by_id if False] if mode == "gold" else ground_context(traces[e.id], by_id, a.budget, mode=mode)
                if mode == "gold":
                    ctx = [p for p in by_id.values() if p.title in set(e.gold_passage_titles)]
                f = featurize(e.question, ctx, e.gold_passage_titles, e.gold_answer, True)
                ok += f["target"] >= 0
            return ok / len(te)
        res, rows_all = {}, {}
        for key in SYS:
            if a.only and key not in a.only.split(","):
                continue
            spec = SPECS[key]
            if key == "closed_book":
                pred = MajorityPrior(tr)
            else:
                torch.manual_seed(seed)
                model = GMRConceptGenerator(grounded=spec.grounded, hops=3)
                feats = make_features(tr, traces, by_id, spec.context_mode, a.budget)
                train(model, feats, epochs=a.epochs, seed=seed, log=lambda s: None, rank_invariance=True, lam_cov=1.0 if spec.grounded else 0.0)
                pred = NeuralPredictor(model)
            rows = evaluate_system(spec, te, traces, by_id, pred, budget=a.budget)
            rows_all[key] = rows
            res[key] = {**{m: M.aggregate(rows)[m] for m in ("em", "f1", "evidence_recall", "hop_completion")}, "n_test": len(te)}
        info = dict(te=te, traces=traces, by_id=by_id)
        tk = topk_from_rows(rows_all, info, a.budget, 3)
        for key in res:
            res[key].update(tk.get(key, {}))
        res["_ceiling"] = {"gold_passages": ceiling("gold"), "retrieved_multihop5": ceiling("multihop"), "retrieved_top5": ceiling("top_k")}
        per_seed[str(seed)] = res
        print(name, "seed", seed, {k: round(v["em"], 3) for k, v in res.items() if k != "_ceiling"}, res["_ceiling"], flush=True)
    out["reading"] = per_seed
    out["total_s"] = round(time.time() - t0, 1)
    return name, out


if __name__ == "__main__":
    results = {}
    for n in a.datasets.split(","):
        k, v = run_dataset(n); results[k] = v
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        json.dump({"config": vars(a), "results": results}, open(a.out, "w"), indent=1, default=float)
