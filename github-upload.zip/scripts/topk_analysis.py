#!/usr/bin/env python
"""Recompute Top-k dependence / excess dependence from saved predictions (k < budget so the metric is non-vacuous).
Rebuilds the synthetic world deterministically from the run's seed; for real data pass the same traces/corpus."""
import argparse, glob, json, os
import numpy as np
from gmrncm.data.synthetic import build_world
from gmrncm.pipeline import split, build_traces
from gmrncm.grounding import ground_context
from gmrncm.verifier import LexicalVerifier
from gmrncm import metrics as M

ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True); ap.add_argument("--n_questions", type=int, default=300)
ap.add_argument("--seed", type=int, default=0); ap.add_argument("--budget", type=int, default=5); ap.add_argument("--k", type=int, default=3)
a = ap.parse_args()
ex, corpus = build_world(a.n_questions, seed=a.seed)
_, _, te = split(ex, a.seed)
traces, by_id = build_traces(ex, corpus)
exm = {e.id: e for e in te}
ver = LexicalVerifier()
out = {}
for f in sorted(glob.glob(f"{a.run}/predictions/*.jsonl")):
    name = os.path.basename(f)[:-6]
    spec_mode = "top_k" if name in {"ref_top5", "gmr_noiter"} else "multihop"
    share, dep, exc = [], [], []
    for line in open(f):
        r = json.loads(line)
        if name == "closed_book" or not r["generated_reasoning"]:
            continue
        e = exm[r["id"]]
        ctx = ground_context(traces[e.id], by_id, a.budget, mode=spec_mode)
        tab = M.claim_support_table(r["generated_reasoning"], ctx, ver)
        gold_ranks = [i + 1 for i, p in enumerate(ctx) if p.title in set(e.gold_passage_titles)]
        share.append(M.topk_claim_share(tab, a.k)); dep.append(M.topk_dependence(tab, a.k))
        exc.append(M.excess_topk(tab, gold_ranks, a.k) if gold_ranks else float("nan"))
    nm = lambda v: float(np.nanmean(v)) if len(v) else float("nan")
    out[name] = {f"top{a.k}_claim_share": nm(share), f"top{a.k}_dependence": nm(dep), f"top{a.k}_excess_dep": nm(exc)}
json.dump(out, open(f"{a.run}/topk_k{a.k}.json", "w"), indent=1)
print(a.run, {k: round(v[f"top{a.k}_dependence"], 3) for k, v in out.items()})
