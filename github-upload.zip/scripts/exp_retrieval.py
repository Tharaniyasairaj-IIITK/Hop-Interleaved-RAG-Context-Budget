#!/usr/bin/env python
"""Retrieval-level experiments (no model training): (i) rank of each chain-position gold passage under
question-only retrieval; (ii) full-chain evidence recall vs passage budget B for top-k vs hop-interleaved context,
under increasing distractor counts; (iii) per-hop gold coverage. 5 seeds."""
import json, argparse, numpy as np
from gmrncm.data.synthetic import build_world
from gmrncm.retrieval import BM25Retriever
from gmrncm.multihop import IterativeRetriever
from gmrncm.grounding import ground_context

ap = argparse.ArgumentParser(); ap.add_argument("--seeds", type=int, default=5); ap.add_argument("--n", type=int, default=300)
ap.add_argument("--out", default="results/retrieval_exp.json"); a = ap.parse_args()
BS = [1, 2, 3, 4, 5, 6, 8, 10]; NOISE = [100, 400, 1600]
out = {"ranks": {}, "recall": {}, "hop_cov": {}}
for noise in NOISE:
    ranks = {1: [], 2: [], 3: []}; rec = {m: {b: [] for b in BS} for m in ("top_k", "multihop")}; frac = {m: {b: [] for b in BS} for m in ("top_k", "multihop")}
    for seed in range(a.seeds):
        ex, corpus = build_world(a.n, seed=seed, n_noise=noise, abstain_frac=0.0)
        r = BM25Retriever(corpus); it = IterativeRetriever(r, corpus, hops=3, per_hop_k=10); by = {p.passage_id: p for p in corpus}
        for e in ex:
            gold = [f"wiki:{t.replace(' ', '_')}::0000" for t in e.gold_passage_titles]
            full = [p for p, _ in r.search(e.question, 500)]
            for pos, g in enumerate(gold, start=1):
                ranks[pos].append(full.index(g) + 1 if g in full else 501)
            tr = it.run(e.id, e.question).to_dict()
            for m in ("top_k", "multihop"):
                for b in BS:
                    ctx = {p.passage_id for p in ground_context(tr, by, b, mode=m)}
                    rec[m][b].append(float(all(g in ctx for g in gold))); frac[m][b].append(np.mean([g in ctx for g in gold]))
        print("noise", noise, "seed", seed, flush=True)
    out["ranks"][noise] = {k: v for k, v in ranks.items()}
    out["recall"][noise] = {m: {b: [float(np.mean(v)), float(np.std(v))] for b, v in d.items()} for m, d in rec.items()}
    out["hop_cov"][noise] = {m: {b: float(np.mean(v)) for b, v in d.items()} for m, d in frac.items()}
json.dump(out, open(a.out, "w"))
