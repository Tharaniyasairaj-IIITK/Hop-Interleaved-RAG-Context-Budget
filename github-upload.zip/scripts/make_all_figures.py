#!/usr/bin/env python
"""Data figures for the paper, generated only from saved result files (no hand-typed numbers)."""
import json, glob, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.alpha": .25, "figure.dpi": 150})
C = {"top": "#0072B2", "multi": "#E69F00", "gmr": "#009E73", "norank": "#D55E00", "grey": "#7f7f7f"}
O = "paper/figures/"
R = json.load(open("results/retrieval_exp.json"))

# F1: rank of gold passages by chain position (noise=400 default world) + per-noise median
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.6))
for pos, lab, c in [("1", "hop-1 gold (film)", C["top"]), ("2", "hop-2 gold (director)", C["multi"]), ("3", "hop-3 gold (city)", C["gmr"])]:
    v = np.sort(np.array(R["ranks"]["400"][pos])); ax[0].step(np.minimum(v, 60), np.arange(1, len(v) + 1) / len(v), where="post", label=lab, color=c)
ax[0].axvline(5, ls="--", c=C["grey"], lw=.8); ax[0].text(5.5, .05, "B=5", fontsize=7, color=C["grey"])
ax[0].set_xlabel("rank under question-only retrieval (capped at 60)"); ax[0].set_ylabel("cumulative fraction"); ax[0].legend(fontsize=6.5, loc="lower right")
ax[0].set_title("Later-hop evidence ranks lower", fontsize=8)
ns = ["100", "400", "1600"]
for pos, c in [("2", C["multi"]), ("3", C["gmr"])]:
    ax[1].plot(range(3), [np.mean(np.array(R["ranks"][n][pos]) > 5) for n in ns], marker="o", c=c, label=f"chain position {pos}")
ax[1].set_xticks(range(3)); ax[1].set_xticklabels(ns); ax[1].set_xlabel("# distractor passages"); ax[1].set_ylabel("fraction outside question-only top-5"); ax[1].set_ylim(0, 1)
ax[1].legend(fontsize=6.5); ax[1].set_title("...and the gap depends on the corpus", fontsize=8)
plt.tight_layout(); plt.savefig(O + "fig_gold_rank.pdf"); plt.savefig(O + "fig_gold_rank.png", dpi=170); plt.close()

# F2: full-chain recall vs B
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.4), sharey=True)
for a, n in zip(ax, ns):
    for m, lab, c in [("top_k", "top-k (question only)", C["top"]), ("multihop", "hop-interleaved", C["multi"])]:
        bs = sorted(int(b) for b in R["recall"][n][m]); mu = np.array([R["recall"][n][m][str(b)][0] for b in bs]); sd = 1.96 * np.sqrt(mu * (1 - mu) / 1500)  # binomial 95% CI, N=5 seeds x 300 questions
        a.plot(bs, mu, marker="o", ms=3, label=lab, c=c); a.fill_between(bs, mu - sd, mu + sd, color=c, alpha=.15)
    a.set_title(f"{n} distractors", fontsize=8); a.set_xlabel("passage budget B")
ax[0].set_ylabel("full-chain evidence recall"); ax[0].legend(fontsize=6.5, loc="lower right")
plt.tight_layout(); plt.savefig(O + "fig_recall_budget.pdf"); plt.savefig(O + "fig_recall_budget.png", dpi=170); plt.close()

# F3: order robustness
S = [json.load(open(f)) for f in sorted(glob.glob("results/shuffle/seed*.json"))]
names = [("ref_multihop5", "Flat reader", C["multi"]), ("gmr_full", "GMR (full)", C["gmr"]), ("gmr_norankinv", "GMR w/o $\\mathcal{L}_{rank}$", C["norank"])]
fig, ax = plt.subplots(figsize=(3.6, 2.6)); w = .36
for i, (k, lab, c) in enumerate(names):
    o = [s[k]["orig"] for s in S]; sh = [s[k]["shuffled_mean"] for s in S]
    ax.bar(i - w / 2, np.mean(o), w, color=c, alpha=.9, label="original order" if i == 0 else None); ax.bar(i + w / 2, np.mean(sh), w, color=c, alpha=.45, hatch="//", label="shuffled order" if i == 0 else None)
    ax.scatter([i - w / 2] * len(o), o, s=7, c="k", zorder=3); ax.scatter([i + w / 2] * len(sh), sh, s=7, c="k", zorder=3)
ax.set_xticks(range(3)); ax.set_xticklabels([n[1] for n in names], fontsize=7); ax.set_ylabel("EM (answerable)"); ax.set_ylim(.3, 1.02); ax.legend(fontsize=6.5, loc="lower left")
ax.set_title(f"Order robustness ({len(S)} seeds; dots = seeds)", fontsize=8)
plt.tight_layout(); plt.savefig(O + "fig_shuffle.pdf"); plt.savefig(O + "fig_shuffle.png", dpi=170); plt.close()

# F4: ablations from the notebook suite (5 seeds)
SU = json.load(open("results/notebook_suite.json"))["per_seed"]
keys = ["ref_top5", "ref_multihop5", "gmr_noiter", "gmr_noverify", "gmr_norankinv", "gmr_full"]
lab = ["Flat\ntop-5", "Flat\nmultihop-5", "GMR\nno-iter", "GMR\nno-verify", "GMR\nno-rank", "GMR\nfull"]
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.5))
for a_, met, t_ in zip(ax, ["em_answerable", "hop_completion"], ["Exact match, answerable", "Hop completion"]):
    for i, k in enumerate(keys):
        v = [SU[s][k][met] for s in SU]
        a_.bar(i, np.mean(v), color=C["gmr"] if k == "gmr_full" else C["grey"], alpha=.85); a_.scatter([i] * len(v), v, s=8, c="k", zorder=3)
    a_.set_xticks(range(len(keys))); a_.set_xticklabels(lab, fontsize=6); a_.set_title(t_ + f" ({len(SU)} seeds)", fontsize=8); a_.set_ylim(0, 1.05)
plt.tight_layout(); plt.savefig(O + "fig_ablation.pdf"); plt.savefig(O + "fig_ablation.png", dpi=170); plt.close()

# F5: feasibility
F = json.load(open("results/feasibility.json")); lv = F["xsum_config"]["levels"]; P = F["xsum_config"]["prefix_len"]
pos_ncm = sum(P + l for l in lv); pos_ar = P + lv[-1]
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.3))
ax[0].bar(["NCM\n(9 levels)", "AR\n(48 tokens)"], [F["sequential_passes"]["ncm"], F["sequential_passes"]["ar_48"]], color=[C["gmr"], C["grey"]]); ax[0].set_title("sequential forward passes", fontsize=8)
ax[1].bar(["NCM\nno cache", "AR\nKV cache"], [pos_ncm, pos_ar], color=[C["gmr"], C["grey"]]); ax[1].set_title("token positions processed", fontsize=8)
ax[2].bar(["NCM", "AR"], [F["latency_s"]["ncm_mean"], F["latency_s"]["ar_mean"]], yerr=[np.std(F["latency_s"]["ncm_all"]), np.std(F["latency_s"]["ar_all"])], color=[C["gmr"], C["grey"]]); ax[2].set_title("CPU wall-clock (s), random weights", fontsize=8)
plt.tight_layout(); plt.savefig(O + "fig_feasibility.pdf"); plt.savefig(O + "fig_feasibility.png", dpi=170); plt.close()
print("positions", pos_ncm, pos_ar, "ratio", pos_ncm / pos_ar)
