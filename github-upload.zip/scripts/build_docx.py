#!/usr/bin/env python
"""Build the DOCX from paper/main.tex via a pandoc-friendly copy (native Word equations, PNG figures)."""
import re, subprocess, os
os.chdir("paper")
s = open("main.tex").read()
def inline(m):
    t = open(m.group(1)).read()
    return re.sub(r"\\resizebox\{\\linewidth\}\{!\}\{(\\begin\{tabular\}.*?\\end\{tabular\})\}", r"\1", t, flags=re.S)
s = re.sub(r"\\input\{(tables/[^}]+)\}", inline, s)
s = re.sub(r"\\resizebox\{\\linewidth\}\{!\}\{(\\begin\{tabular\}.*?\\end\{tabular\})\}", r"\1", s, flags=re.S)
s = s.replace("\\usepackage[preprint]{neurips_local}", "").replace("\\newcommand{\\tbd}{\\textcolor{gray}{--}}", "\\newcommand{\\tbd}{--}")
a = s.index("\\begin{algorithm}[t]"); b = s.index("\\end{algorithm}") + len("\\end{algorithm}")
alg = ("\\paragraph{Algorithm 1: \\gmr{} inference.} Input: question $q$, retriever $R$, hops $H$, budget $B$, threshold $\\tau$.\n\\begin{enumerate}\n"
       "\\item Decompose $q$ into sub-queries; set $u_1\\leftarrow q$, $s_0\\leftarrow \\mathrm{enc}(q)$.\n"
       "\\item For $h=1,\\dots,H$: retrieve $D_h\\leftarrow R(u_h)$; select $\\Cset_h\\leftarrow\\mathrm{HopInterleave}(D_{1:h},B)$; compute routing $\\alpha^{(h)}$ (Eq.~\\ref{eq:route}), codes $\\tilde z_h\\leftarrow\\mathrm{RVQ}(\\sum_i\\alpha^{(h)}_iP_i)$ and state $s_h\\leftarrow s_{h-1}+\\mathrm{emb}(\\tilde z_h)$; next query $u_{h+1}\\leftarrow q\\oplus E_h$ (Eq.~\\ref{eq:hopq}).\n"
       "\\item Decode the fine levels $y\\sim p(y\\mid s_H,\\Cset_H)$ (parallel within each level).\n"
       "\\item For each atomic claim $a$ in $y$ compute $v_a=\\max_{d\\in\\Cset_H}v(a,d)$.\n"
       "\\item If the final-answer claim has $v_a<\\tau$ return \\textsc{insufficient\\_evidence}; otherwise return $y$, the cited IDs and the concept trace.\n\\end{enumerate}")
s = s[:a] + alg + s[b:]
# highlight box -> blockquote-like paragraph
s = re.sub(r"\\fcolorbox\{black\}\{yellow!12\}\{\\parbox\{0\.96\\linewidth\}\{\\small(.*?)\}\}", r"\\begin{quote}\1\\end{quote}", s, flags=re.S)
s = s.replace("\\sloppy", "").replace("\\allowbreak ", "").replace("\\allowbreak", "")
s = re.sub(r"(figures/[A-Za-z_]+)\.pdf", r"\1.png", s)
s = s.replace("\\bibliography{refs}", "\\section*{References}\n::: {#refs}\n:::").replace("\\citep{", "\\cite{")
open("main_pandoc.tex", "w").write(s)
subprocess.run(["pandoc", "main_pandoc.tex", "-f", "latex", "-t", "docx", "--citeproc", "--bibliography=refs.bib", "-o", "main.docx", "--resource-path=."], check=True)
os.remove("main_pandoc.tex")
import docx
d = docx.Document("main.docx"); print("docx: tables", len(d.tables), "images", len(d.inline_shapes))
