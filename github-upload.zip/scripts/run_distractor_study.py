"""Natural-distractor scaling on real data: the dev corpus of one dataset is enlarged with passages of the other two
datasets (Wikipedia text, topically unrelated to most questions). Recall@k of BM25 vs GMR-NCM retrieval is measured as the
corpus grows. Output: results/real/distractor_<dataset>.json"""
import argparse, json, random, sys, time
import numpy as np
sys.path.insert(0, "src")
from gmrncm.data.hippo import load_hippo_subset
from gmrncm.pipeline import build_traces
from gmrncm.grounding import ground_context
ap = argparse.ArgumentParser(); ap.add_argument("--dataset", required=True); ap.add_argument("--fracs", default="0.5,1.0"); ap.add_argument("--root", default="data/real")
a = ap.parse_args()
ex, own = load_hippo_subset(a.dataset, a.root)
own_texts = {p.text for p in own}
foreign = []
for o in ("hotpotqa", "2wiki", "musique"):
    if o != a.dataset:
        _, c = load_hippo_subset(o, a.root); foreign += [p for p in c if p.text not in own_texts]
random.Random(0).shuffle(foreign)
gold_ids = {e.id: {p.passage_id for p in own if p.title in set(e.gold_passage_titles)} for e in ex}
out = {"dataset": a.dataset, "own": len(own), "foreign_pool": len(foreign), "points": []}
for fr in [float(f) for f in a.fracs.split(",")]:
    t0 = time.time(); corpus = own + foreign[: int(fr * len(foreign))]
    traces, by_id = build_traces(ex, corpus)
    pt = {"frac": fr, "corpus": len(corpus)}
    for k in (2, 5):
        for mode, nm in (("top_k", "bm25"), ("multihop", "gmr")):
            r = [len({p.passage_id for p in ground_context(traces[e.id], by_id, k, mode)} & gold_ids[e.id]) / len(gold_ids[e.id]) for e in ex]
            pt[f"{nm}_R@{k}"] = float(np.mean(r))
    pt["s"] = round(time.time() - t0, 1); out["points"].append(pt); print(a.dataset, pt, flush=True)
    json.dump(out, open(f"results/real/distractor_{a.dataset}.json", "w"), indent=1)
