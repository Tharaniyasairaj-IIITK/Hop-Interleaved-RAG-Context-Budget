"""Tables for the WWW short paper: real-data retrieval (measured + published baselines) and reader results."""
import json, glob, numpy as np
from pathlib import Path
R = {}
for f in glob.glob("results/real/bench_*.json"):
    R.update(json.load(open(f))["results"])
DS = [("musique", "MuSiQue"), ("2wiki", "2Wiki"), ("hotpotqa", "HotpotQA")]   # column order as in the HippoRAG tables
# Published numbers, as reported by Gutierrez et al. (HippoRAG, NeurIPS 2024), Tables 2-4 (same 1,000-question dev subsets): R@2,R@5 x (MuSiQue, 2Wiki, HotpotQA)
PUB_RET = [
 ("BM25~\\cite{robertson2009bm25}", [32.3,41.2,51.8,61.9,55.4,72.2]),
 ("Contriever~\\cite{izacard2022contriever}", [34.8,46.6,46.6,57.5,57.2,75.5]),
 ("GTR~\\cite{ni2022gtr}", [37.4,49.1,60.2,67.9,59.4,73.3]),
 ("ColBERTv2~\\cite{santhanam2022colbertv2}", [37.9,49.2,59.2,68.2,64.7,79.3]),
 ("HippoRAG (ColBERTv2)~\\cite{gutierrez2024hipporag}", [40.9,51.9,70.7,89.1,60.5,77.7]),
 ("IRCoT + BM25~\\cite{trivedi2023ircot}", [34.2,44.7,61.2,75.6,65.6,79.0]),
 ("IRCoT + HippoRAG (ColBERTv2)", [45.3,57.6,75.8,93.9,67.0,83.0]),
]
PUB_QA = [  # EM,F1 x (MuSiQue, 2Wiki, HotpotQA); LLM reader, as reported in the same paper
 ("No retrieval", [12.5,24.1,31.0,39.6,30.4,42.8]),
 ("ColBERTv2", [15.5,26.4,33.4,43.3,43.4,57.7]),
 ("IRCoT (ColBERTv2)", [19.1,30.5,35.4,45.1,45.5,58.4]),
 ("HippoRAG (ColBERTv2)", [19.2,29.8,46.6,59.5,41.8,55.0]),
 ("IRCoT + HippoRAG", [21.9,33.3,47.7,62.7,45.7,59.2]),
]
def avg(v): return [round(np.mean(v[0::2]),1), round(np.mean(v[1::2]),1)]
lines = ["\\begin{tabular}{@{}lcccccccc@{}}", "\\toprule",
         "& \\multicolumn{2}{c}{MuSiQue} & \\multicolumn{2}{c}{2Wiki} & \\multicolumn{2}{c}{HotpotQA} & \\multicolumn{2}{c}{Avg.}\\\\",
         "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(lr){6-7}\\cmidrule(l){8-9}",
         "Retriever & R@2 & R@5 & R@2 & R@5 & R@2 & R@5 & R@2 & R@5\\\\", "\\midrule",
         "\\multicolumn{9}{@{}l}{\\emph{Reported baselines$^\\dagger$ (dense / LLM-based retrievers)}}\\\\"]
for n, v in PUB_RET:
    lines.append(n + " & " + " & ".join(f"{x:.1f}" for x in v + avg(v)) + "\\\\")
lines += ["\\midrule", "\\multicolumn{9}{@{}l}{\\emph{Measured here (no neural retriever, no LLM)}}\\\\"]
def meas(key):
    v = []
    for d, _ in DS:
        for k in ("R@2", "R@5"):
            v.append(100 * R[d]["retrieval"][k][key])
    return v
for label, key in [("BM25, single step (ours)", "bm25_single"), ("\\textbf{GMR-NCM retrieval} (3 hops, RRF merge)", "gmr_rrf_merged"), ("\\textbf{GMR-NCM retrieval} (hop-interleaved)", "gmr_hop_interleaved")]:
    v = meas(key); lines.append(label + " & " + " & ".join(f"{x:.1f}" for x in v + avg(v)) + "\\\\")
lines += ["\\bottomrule", "\\end{tabular}"]
Path("short/tables/retrieval.tex").write_text("\n".join(lines))

def ms(vals, pct=True):
    v = np.array(vals) * (100 if pct else 1); return f"{v.mean():.1f}$\\pm${v.std(ddof=0):.1f}"
sysn = [("closed_book", "Majority answer (closed-book)"), ("ref_top5", "Flat reader + top-5"), ("ref_multihop5", "Flat reader + multihop-5 (control)"),
        ("gmr_noiter", "GMR-NCM w/o iterative retrieval"), ("gmr_full", "\\textbf{GMR-NCM (full)}")]
L = ["\\begin{tabular}{@{}lcccccc@{}}", "\\toprule", "& \\multicolumn{2}{c}{MuSiQue} & \\multicolumn{2}{c}{2Wiki} & \\multicolumn{2}{c}{HotpotQA}\\\\",
     "\\cmidrule(lr){2-3}\\cmidrule(lr){4-5}\\cmidrule(l){6-7}", "System & EM & F1 & EM & F1 & EM & F1\\\\", "\\midrule",
     "\\multicolumn{7}{@{}l}{\\emph{Reported baselines$^\\dagger$ (LLM reader, different protocol)}}\\\\"]
for n, v in PUB_QA:
    L.append(n + " & " + " & ".join(f"{x:.1f}" for x in v) + "\\\\")
L += ["\\midrule", "\\multicolumn{7}{@{}l}{\\emph{Measured here (extractive reference reader, 600 training questions, 3 seeds)}}\\\\"]
for key, label in sysn:
    cells = []
    for d, _ in DS:
        seeds = R[d]["reading"]
        cells += [ms([seeds[s][key]["em"] for s in seeds]), ms([seeds[s][key]["f1"] for s in seeds])]
    L.append(label + " & " + " & ".join(cells) + "\\\\")
cl = []
for d, _ in DS:
    seeds = R[d]["reading"]; cl.append(np.mean([seeds[s]["_ceiling"]["gold_passages"] for s in seeds]) * 100)
L.append("Reader ceiling (answer extractable from gold passages) & " + " & ".join(f"\\multicolumn{{2}}{{c}}{{{c:.1f}}}" for c in cl) + "\\\\")
L += ["\\bottomrule", "\\end{tabular}"]
Path("short/tables/reading.tex").write_text("\n".join(L))
print("\n".join(lines)); print("\n".join(L))
