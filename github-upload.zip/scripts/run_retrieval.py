#!/usr/bin/env python
"""Precompute top-k and multihop retrieval traces (frozen, reproducible)."""
import argparse, json
from pathlib import Path
from gmrncm.schema import load_examples, load_passages
from gmrncm.retrieval import BM25Retriever
from gmrncm.multihop import IterativeRetriever

ap = argparse.ArgumentParser()
ap.add_argument("--questions", required=True); ap.add_argument("--corpus", required=True)
ap.add_argument("--retriever", default="bm25", help="bm25 | dense:<hf-model>")
ap.add_argument("--hops", type=int, default=3); ap.add_argument("--per_hop_k", type=int, default=20)
ap.add_argument("--output", required=True)
a = ap.parse_args()
corpus = load_passages(a.corpus); ex = load_examples(a.questions)
if a.retriever.startswith("dense:"):
    from gmrncm.retrieval import DenseRetriever
    r = DenseRetriever(corpus, a.retriever.split(":", 1)[1])
else:
    r = BM25Retriever(corpus)
it = IterativeRetriever(r, corpus, hops=a.hops, per_hop_k=a.per_hop_k)
Path(a.output).parent.mkdir(parents=True, exist_ok=True)
with open(a.output, "w") as f:
    for e in ex:
        f.write(json.dumps(it.run(e.id, e.question).to_dict()) + "\n")
