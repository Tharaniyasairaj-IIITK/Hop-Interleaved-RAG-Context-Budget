#!/usr/bin/env python
"""Pandoc-friendly copy of short/main.tex (acmart -> article, tables inlined) -> short/short.docx."""
import re, subprocess, os
os.chdir("short")
s = open("main.tex").read()
s = s.replace("\\documentclass[sigconf,anonymous,review]{acmart}", "\\documentclass{article}\\usepackage{graphicx,booktabs,amsmath,multirow}")
for pat in [r"\\settopmatter.*\n", r"\\renewcommand\\footnotetextcopyrightpermission.*\n", r"\\pagestyle.*\n", r"\\setcopyright.*\n", r"\\acmConference.*\n",
            r"\\acmYear.*\n", r"\\renewcommand\{\\shortauthors\}.*\n", r"\\ccsdesc.*\n", r"\\setlength\{\\(?:textfloatsep|floatsep|intextsep)\}\{[^}]*\}\n"]:
    s = re.sub(pat, "", s)
s = re.sub(r"\\begin\{CCSXML\}.*?\\end\{CCSXML\}\n", "", s, flags=re.S)
s = s.replace("\\keywords{", "\\textbf{Keywords:} ").replace("attribution}\n\\maketitle", "attribution.\n\\maketitle")
s = s.replace("\\bibliographystyle{ACM-Reference-Format}\n\\bibliography{refs}", "\\section*{References}\n::: {#refs}\n:::")
a = s.index("\\begin{algorithm}"); b = s.index("\\end{algorithm}") + len("\\end{algorithm}")
alg = ("\\textbf{Algorithm 1: \\gmr{} inference.} Input: question $q$, retriever $R$, hops $H$, budget $B$, threshold $\\tau$.\n\\begin{enumerate}\n"
       "\\item $u_1\\leftarrow q$; $s_0\\leftarrow\\mathrm{enc}(q)$.\n"
       "\\item For $h=1,\\dots,H$: $D_h\\leftarrow R(u_h)$; $\\mathcal{C}_h\\leftarrow\\mathrm{HopInterleave}(D_{1:h},B)$; compute $\\alpha^{(h)},\\tilde z_h$ by Eq.~\\ref{eq:route} and $s_h\\leftarrow s_{h-1}+\\mathrm{emb}(\\tilde z_h)$; $u_{h+1}\\leftarrow q\\oplus E_h$ by Eq.~\\ref{eq:hop}.\n"
       "\\item Decode $y$ coarse-to-fine from $(s_H,\\mathcal{C}_H)$ and split it into claims $a$.\n"
       "\\item If the answer claim has $\\max_{d\\in\\mathcal{C}_H}v(a,d)<\\tau$, return INSUFFICIENT\\_EVIDENCE; otherwise return $y$, the cited IDs and the concept trace.\n\\end{enumerate}")
s = s[:a] + alg + s[b:]
def strip2float(m):
    b = m.group(1); out = ""
    f = re.search(r"\\centering\\includegraphics\[[^\]]*\]\{([^}]*)\}\s*\\captionof\{figure\}\{(.*?)\}(\\label\{[^}]*\})", b, re.S)
    if f: out += "\\begin{figure}\n\\includegraphics{%s}\n\\caption{%s}%s\n\\end{figure}\n" % (f.group(1), f.group(2), f.group(3))
    t = re.search(r"\\captionof\{table\}\{(.*?)\}(\\label\{[^}]*\})\s*\\centering\\scriptsize\s*(\\input\{[^}]+\})", b, re.S)
    if t: out += "\\begin{table}\n\\caption{%s}%s\n%s\n\\end{table}\n" % (t.group(1), t.group(2), t.group(3))
    return out
s = re.sub(r"\\begin\{strip\}\n(.*?)\\end\{strip\}", strip2float, s, flags=re.S)
s = s.replace("figure*", "figure").replace("table*", "table").replace("[t]", "[h]")
s = s.replace("\\centering\\scriptsize\\setlength{\\tabcolsep}{3pt}", "\\centering").replace("\\centering\\scriptsize", "\\centering")
inline = lambda m: re.sub(r"\\cmidrule(\([lr]+\))?\{[^}]*\}", "", open(m.group(1)).read()).replace("@{}", "")
s = re.sub(r"\\input\{(tables/[^}]+)\}", inline, s)
s = s.replace("figures/arch_short.pdf", "figures/arch_short.png").replace("figures/fig_recall_real.pdf", "figures/fig_recall_real.png")
open("short_pandoc.tex", "w").write(s)
subprocess.run("pandoc short_pandoc.tex -f latex -t docx --citeproc --bibliography=refs.bib -o short.docx --resource-path=.", shell=True, check=True)
os.remove("short_pandoc.tex")
import docx; d = docx.Document("short.docx"); print("docx: tables", len(d.tables), "images", len(d.inline_shapes))
