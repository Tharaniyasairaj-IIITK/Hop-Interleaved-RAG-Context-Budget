#!/usr/bin/env python
"""Generate LaTeX tables from results/runs/<run>/metrics/*.json (no hand-typed numbers).
Pass several --run dirs (one per seed) to get mean +- std over seeds."""
import argparse, json, glob, os
import numpy as np

ap = argparse.ArgumentParser()
ap.add_argument("--run", nargs="+", default=["results/runs/smoke_s0"]); ap.add_argument("--out", default="paper/tables")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
runs = []
for r in a.run:
    runs.append({os.path.basename(p)[:-5]: json.load(open(p))["summary"] for p in glob.glob(f"{r}/metrics/*.json")})
order = ["closed_book", "ref_top5", "ref_multihop5", "gmr_noiter", "gmr_noverify", "gmr_norankinv", "gmr_full"]
names = {"closed_book": "Closed-book (answer prior)", "ref_top5": "Flat reader + top-5", "ref_multihop5": "Flat reader + multihop-5 (no grounding)",
         "gmr_noiter": "GMR w/o iterative retrieval", "gmr_noverify": "GMR w/o verification",
         "gmr_norankinv": "GMR w/o rank-invariance", "gmr_full": "\\textbf{GMR (full)}"}
cols = [("em", "EM"), ("f1", "F1"), ("evidence_recall", "ER"), ("hop_completion", "HC"), ("top5_dependence", "Dep$_5$"),
        ("top5_excess_dep", "$\\Delta$Dep$_5$"), ("abstention_acc", "Abst."), ("latency_ms", "Lat.(ms)")]

def cell(k, key):
    v = [r[k][key] for r in runs if k in r and key in r[k] and r[k][key] == r[k][key]]
    if not v:
        return "--"
    m, s = np.mean(v), (np.std(v) if len(v) > 1 else None)
    f = (lambda x: f"{x:.1f}") if key == "latency_ms" else (lambda x: f"{x:.3f}")
    return f(m) + (f"$\\pm${f(s)}" if s is not None else "")

with open(f"{a.out}/pipeline_check.tex", "w") as f:
    f.write("\\resizebox{\\linewidth}{!}{\\begin{tabular}{l" + "r" * len(cols) + "}\n\\toprule\nSystem & " + " & ".join(c[1] for c in cols) + " \\\\\n\\midrule\n")
    for k in order:
        if any(k in r for r in runs):
            f.write(names[k] + " & " + " & ".join(cell(k, c[0]) for c in cols) + " \\\\\n")
    f.write("\\bottomrule\n\\end{tabular}}\n")
json.dump({k: {c[0]: cell(k, c[0]) for c in cols} for k in order if any(k in r for r in runs)}, open(f"{a.out}/pipeline_check.json", "w"), indent=1)
print("wrote", f"{a.out}/pipeline_check.tex", "from", len(runs), "run(s)")
