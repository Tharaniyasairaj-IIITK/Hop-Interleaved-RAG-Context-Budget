#!/usr/bin/env python
"""Paper tables from saved results only. Pipeline-validation table: 3 seeds (mean±std)."""
import json, numpy as np
D = json.load(open("results/notebook_suite.json")); SS = D["per_seed"]; cfgD = D["config"]
def agg(sysname, key):
    v = [SS[s][sysname][key] for s in SS if SS[s][sysname][key] == SS[s][sysname][key]]
    return (np.mean(v), np.std(v)) if v else None
def cell(sysname, key, d=3):
    r = agg(sysname, key)
    return "--" if r is None else f"{r[0]:.{d}f}$\\pm${r[1]:.{d}f}"
NR = "\\multicolumn{%d}{c}{\\emph{not run: needs %s}}"
def row(label, sysname, keys, bold=False):
    l = "\\textbf{" + label + "}" if bold else label
    return l + " & " + " & ".join(cell(sysname, k) for k in keys) + " \\\\"
K2 = ["em", "em_answerable", "f1", "evidence_recall", "hop_completion", "dep_k", "excess_dep_k"]
hdr2 = "System & Context & EM (all) & EM (answ.) & F1 & ER & HC & Dep$_3$ & $\\Delta$Dep$_3$ \\\\"
t2 = ["\\resizebox{\\linewidth}{!}{\\begin{tabular}{llccccccc}", "\\toprule", hdr2, "\\midrule",
      "Closed-book (answer prior) & none & " + " & ".join(cell("closed_book", k) for k in K2) + " \\\\",
      "Flat reader + top-5 (NCM + top-$k$ analogue) & 5 & " + " & ".join(cell("ref_top5", k) for k in K2) + " \\\\",
      "AR LLM + top-5 & 5 & " + NR % (7, "LLM weights, GPU") + " \\\\",
      "AR LLM + multihop-5 & 5 & " + NR % (7, "LLM weights, GPU") + " \\\\",
      "Diffusion LM + top-5 & 5 & " + NR % (7, "diffusion-LM weights, GPU") + " \\\\",
      "Flat reader + multihop-5 (control F: no grounding) & 5 & " + " & ".join(cell("ref_multihop5", k) for k in K2) + " \\\\",
      "\\textbf{GMR (full)} & 5 & " + " & ".join(cell("gmr_full", k) for k in K2) + " \\\\", "\\bottomrule", "\\end{tabular}}"]
open("paper/tables/main_synth.tex", "w").write("\n".join(t2) + "\n")
K3 = ["em", "em_answerable", "evidence_recall", "hop_completion", "excess_dep_k", "abstain_recall"]
t3 = ["\\resizebox{\\linewidth}{!}{\\begin{tabular}{lcccccc}", "\\toprule",
      "Variant & EM (all) & EM (answ.) & ER & HC & $\\Delta$Dep$_3$ & Abst. recall \\\\", "\\midrule",
      row("GMR (full)", "gmr_full", K3, True), row("\\ \\ w/o iterative retrieval", "gmr_noiter", K3),
      row("\\ \\ w/o concept grounding (= flat reader + multihop-5)", "ref_multihop5", K3),
      row("\\ \\ w/o verification", "gmr_noverify", K3), row("\\ \\ w/o $\\mathcal{L}_{\\mathrm{rank}}$", "gmr_norankinv", K3),
      "\\ \\ AR decoder instead of NCM & " + NR % (6, "an AR generator trained on the same task") + " \\\\", "\\bottomrule", "\\end{tabular}}"]
open("paper/tables/ablation_synth.tex", "w").write("\n".join(t3) + "\n")
# shuffle table
S = [json.load(open(f"results/shuffle/seed{s}.json")) for s in range(5)]
nm = {"ref_multihop5": "Flat reader", "gmr_full": "GMR (full)", "gmr_norankinv": "GMR w/o $\\mathcal{L}_{rank}$"}
def lcell(vals, d=3):
    v = [x for x in vals if x == x]
    return "--" if not v else f"{np.mean(v):.{d}f}$\\pm${np.std(v):.{d}f}"
L = [nm[k] + " & " + lcell([s[k]["orig"] for s in S]) + " & " + lcell([s[k]["shuffled_mean"] for s in S]) + " & " + lcell([s[k]["shuffled_min"] for s in S]) + " & " + lcell([s[k]["orig"] - s[k]["shuffled_mean"] for s in S]) + " \\\\" for k in nm]
open("paper/tables/shuffle.tex", "w").write("\\begin{tabular}{lcccc}\n\\toprule\nSystem & Original order & Shuffled (mean of 5) & Shuffled (worst) & Drop \\\\\n\\midrule\n" + "\n".join(L) + "\n\\bottomrule\n\\end{tabular}\n")
F = json.load(open("results/feasibility.json")); P = F["xsum_config"]["prefix_len"]; lv = F["xsum_config"]["levels"]
rows = [("Generator parameters (released XSum architecture)", f"{F['params_generator_M']:.1f} M"), ("Frozen VQ-VAE tokenizer parameters", f"{F['params_tokenizer_M']:.1f} M"),
        ("LoRA trainable parameters, rank 8 / 16 / 32 (analytic)", " / ".join(f"{F['lora_trainable_M'][r]:.2f}" for r in ("8", "16", "32")) + " M"),
        ("Sequential passes: NCM levels vs AR tokens", f"{F['sequential_passes']['ncm']} vs {F['sequential_passes']['ar_48']}"),
        ("Token positions processed (no cache) vs AR with KV cache", f"{sum(P+l for l in lv)} vs {P+lv[-1]}"),
        ("Positions if the prefix were cached once (analytic, not measured)", f"{P+sum(lv)}"),
        ("CPU wall-clock, NCM vs size-matched AR (s, 3 reps)", f"{F['latency_s']['ncm_mean']:.2f} vs {F['latency_s']['ar_mean']:.2f}")]
open("paper/tables/feasibility.tex", "w").write("\\begin{tabular}{lr}\n\\toprule\nQuantity & Value\\\\\n\\midrule\n" + "\n".join(a + " & " + b + " \\\\" for a, b in rows) + "\n\\bottomrule\n\\end{tabular}\n")
print(open("paper/tables/main_synth.tex").read()); print(open("paper/tables/ablation_synth.tex").read())
