"""Empirical check of the interleaving-coverage lemma on real data.
Lemma: if every gold passage lies in the top-t of at least one hop list and B >= H*t, the hop-interleaved context contains all gold passages.
For each dataset and t: (i) share of questions satisfying the premise, (ii) measured share with full gold coverage at B=H*t,
(iii) share with full coverage for single-step top-B BM25, (iv) number of per-question violations of the implication (must be 0)."""
import json, sys
sys.path.insert(0, "src")
from gmrncm.data.hippo import load_hippo_subset
from gmrncm.grounding import ground_context
H = 3; out = {}
for d in ("hotpotqa", "2wiki", "musique"):
    ex, corpus = load_hippo_subset(d, "data/real"); by_id = {p.passage_id: p for p in corpus}
    tr = json.load(open(f"results/real/traces_{d}.json"))
    gold = {e.id: {p.passage_id for p in corpus if p.title in set(e.gold_passage_titles)} for e in ex}
    rows = {}
    for t in (1, 2, 3):
        B = H * t; prem = cov = single = viol = 0
        for e in ex:
            lists = [list(dict.fromkeys(r["passage_id"] for r in h["retrieved"])) for h in tr[e.id]["hops"]][:H]
            ok = all(any(g in l[:t] for l in lists) for g in gold[e.id])
            ctx = {p.passage_id for p in ground_context(tr[e.id], by_id, B, "multihop")}
            full = gold[e.id] <= ctx
            s_ctx = {p.passage_id for p in ground_context(tr[e.id], by_id, B, "top_k")}
            prem += ok; cov += full; single += gold[e.id] <= s_ctx; viol += (ok and not full)
        n = len(ex); rows[t] = dict(B=B, premise=prem / n, interleaved=cov / n, single_step=single / n, violations=viol)
    out[d] = rows; print(d, json.dumps(rows))
json.dump(out, open("results/real/lemma_check.json", "w"), indent=1)
