#!/usr/bin/env python
"""Inspect/verify the Stanford NCM pickles with a restricted (code-execution-safe) unpickler; records SHA-256."""
import argparse, json, glob
from gmrncm.ncm_pickles import inspect_pickle
ap = argparse.ArgumentParser(); ap.add_argument("--dir", default="data/ncm_reproduction/xsum")
ap.add_argument("--out", default="results/ncm_pickle_manifest.json"); a = ap.parse_args()
man = [inspect_pickle(p) for p in sorted(glob.glob(f"{a.dir}/*.pickle"))]
json.dump(man, open(a.out, "w"), indent=1); print(json.dumps(man, indent=1))
