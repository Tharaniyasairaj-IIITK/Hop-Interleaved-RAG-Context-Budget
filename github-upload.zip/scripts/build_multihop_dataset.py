#!/usr/bin/env python
"""Convert raw HotpotQA to unified JSONL + corpus (2Wiki/MuSiQue: add converters in gmrncm/data/)."""
import argparse
from gmrncm.data.hotpot import convert_hotpot
from gmrncm.schema import write_jsonl

ap = argparse.ArgumentParser()
ap.add_argument("--hotpot_train"); ap.add_argument("--hotpot_dev")
ap.add_argument("--out", default="data/processed"); ap.add_argument("--train_n", type=int, default=20000)
ap.add_argument("--dev_n", type=int, default=2000)
a = ap.parse_args()
corpus = {}
if a.hotpot_train:
    ex, ps = convert_hotpot(a.hotpot_train, "train", a.train_n); write_jsonl(f"{a.out}/train.jsonl", ex)
    corpus.update({p.passage_id: p for p in ps})
if a.hotpot_dev:
    ex, ps = convert_hotpot(a.hotpot_dev, "dev"); write_jsonl(f"{a.out}/dev.jsonl", ex[: a.dev_n]); write_jsonl(f"{a.out}/test.jsonl", ex[a.dev_n:])
    corpus.update({p.passage_id: p for p in ps})
write_jsonl(f"{a.out}/corpus.jsonl", corpus.values())
print("wrote", len(corpus), "passages")
