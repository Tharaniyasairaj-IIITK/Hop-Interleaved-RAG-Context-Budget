#!/usr/bin/env python
"""Autoregressive LLM baseline (Llama-3.1-8B-Instruct / Qwen2.5-7B-Instruct) with identical prompt + budget.
Requires: pip install transformers accelerate; GPU recommended."""
import argparse, json, time
from gmrncm.schema import load_examples, load_passages, read_jsonl
from gmrncm.grounding import ground_context
from gmrncm.ncm_wrapper import serialize_prompt

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="meta-llama/Llama-3.1-8B-Instruct")
ap.add_argument("--questions", required=True); ap.add_argument("--corpus", required=True); ap.add_argument("--traces", required=True)
ap.add_argument("--context_mode", choices=["top_k", "multihop"], default="top_k"); ap.add_argument("--k", type=int, default=5)
ap.add_argument("--max_new_tokens", type=int, default=512); ap.add_argument("--output", required=True)
a = ap.parse_args()
from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
tok = AutoTokenizer.from_pretrained(a.model); lm = AutoModelForCausalLM.from_pretrained(a.model, torch_dtype=torch.bfloat16, device_map="auto")
by_id = {p.passage_id: p for p in load_passages(a.corpus)}; traces = {t["id"]: t for t in read_jsonl(a.traces)}
with open(a.output, "w") as f:
    for ex in load_examples(a.questions):
        ctx = ground_context(traces[ex.id], by_id, a.k, mode=a.context_mode)
        msgs = [{"role": "user", "content": serialize_prompt(ex.question, ctx)}]
        x = tok.apply_chat_template(msgs, add_generation_prompt=True, return_tensors="pt").to(lm.device)
        t0 = time.perf_counter()
        y = lm.generate(x, max_new_tokens=a.max_new_tokens, do_sample=False)
        txt = tok.decode(y[0, x.shape[1]:], skip_special_tokens=True)
        f.write(json.dumps({"id": ex.id, "system": f"ar_{a.context_mode}{a.k}", "prediction": txt.strip().split("\n")[-1],
                            "raw": txt, "latency_ms": (time.perf_counter() - t0) * 1000,
                            "tokens_generated": int(y.shape[1] - x.shape[1])}) + "\n")
