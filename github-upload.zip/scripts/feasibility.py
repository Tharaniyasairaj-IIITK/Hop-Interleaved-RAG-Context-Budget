#!/usr/bin/env python
"""Feasibility measurements from the OFFICIAL NCM code with the released XSum architecture (random weights, CPU).
Reports: parameter counts, LoRA trainable parameters (analytic), sequential forward passes, and wall-clock of
NCM generation vs a depth/width-matched autoregressive GPT-2 (random weights) on the same CPU.
Latency here is a RELATIVE indicator only (CPU, batch 1, random weights); it is not a quality or GPU claim."""
import argparse, json, sys, time, torch
ap = argparse.ArgumentParser(); ap.add_argument("--repo", default="/home/claude/hazyresearch/ncm")
ap.add_argument("--reps", type=int, default=3); ap.add_argument("--out", default="results/feasibility.json"); a = ap.parse_args()
sys.path.insert(0, a.repo); torch.set_num_threads(2)
from omegaconf import OmegaConf
from models.vqvae import VQVAE
from models.next_concept import NextConceptTransformer
CFG = OmegaConf.load(f"{a.repo}/config/eval/xsum.yaml")
vq = VQVAE(**CFG.tokenizer.vqvae).eval()
net = NextConceptTransformer(vqvae_local=vq, config=CFG.model).eval()
n_gen = sum(p.numel() for p in net.parameters()); n_tok = sum(p.numel() for p in vq.parameters())
lin = [(m.in_features, m.out_features) for blk in net.transformer.blocks for m in blk.modules() if isinstance(m, torch.nn.Linear)]
lora = {r: sum(r * (i + o) for i, o in lin) for r in (8, 16, 32)}
levels = list(net.levels); L_tgt = sum(levels)
P = int(CFG.model.prefix_len)
pre = torch.randint(0, 50256, (1, P))
def t_ncm():
    t = time.perf_counter()
    with torch.no_grad(): net.generate(None, pre, temperature=0.0, top_k=1, top_p=0.0, use_kv_cache=False)
    return time.perf_counter() - t
from transformers import GPT2Config, GPT2LMHeadModel
ar = GPT2LMHeadModel(GPT2Config(n_layer=int(CFG.model.n_layer), n_head=int(CFG.model.n_head), n_embd=int(CFG.model.n_embd), n_positions=P + 64)).eval()
n_ar = sum(p.numel() for p in ar.parameters())
def t_ar(T=48):
    t = time.perf_counter()
    with torch.no_grad(): ar.generate(pre, max_new_tokens=T, min_new_tokens=T, do_sample=False, pad_token_id=0)
    return time.perf_counter() - t
t_ncm(); t_ar(4)  # warm-up
nc = [t_ncm() for _ in range(a.reps)]; arr = [t_ar() for _ in range(a.reps)]
out = {"xsum_config": {"n_layer": int(CFG.model.n_layer), "n_embd": int(CFG.model.n_embd), "prefix_len": P, "levels": levels, "target_tokens": int(levels[-1]),
       "codebook": int(CFG.model.vocab_size[0])},
       "params_generator_M": n_gen / 1e6, "params_tokenizer_M": n_tok / 1e6, "params_ar_gpt2_M": n_ar / 1e6,
       "lora_trainable_M": {str(r): v / 1e6 for r, v in lora.items()},
       "sequential_passes": {"ncm": len(levels), "ar_48": levels[-1]},
       "latency_s": {"ncm_mean": sum(nc) / len(nc), "ncm_all": nc, "ar_mean": sum(arr) / len(arr), "ar_all": arr},
       "hardware": f"CPU, {torch.get_num_threads()} threads, batch 1, random weights, no KV cache for NCM / KV cache for AR",
       "torch": torch.__version__}
json.dump(out, open(a.out, "w"), indent=1); print(json.dumps(out, indent=1))
