#!/usr/bin/env bash
# Download official NCM assets and the multihop datasets. Requires internet + `pip install huggingface_hub`.
set -euo pipefail
mkdir -p artifacts data/raw/{hotpotqa,2wiki,musique,wikipedia} data/ncm_reproduction
git clone https://github.com/HazyResearch/ncm.git third_party/ncm || true
hf download hazyresearch/ncm-checkpoints --local-dir artifacts/ncm-checkpoints
hf download hazyresearch/ncm-datasets --repo-type dataset --local-dir data/ncm_reproduction
# HotpotQA (distractor + fullwiki dev/train): see https://hotpotqa.github.io/
wget -nc http://curtis.ml.cmu.edu/datasets/hotpot/hotpot_train_v1.1.json -P data/raw/hotpotqa/
wget -nc http://curtis.ml.cmu.edu/datasets/hotpot/hotpot_dev_distractor_v1.json -P data/raw/hotpotqa/
# 2WikiMultihopQA: https://github.com/Alab-NII/2wikimultihop   MuSiQue: https://github.com/StonyBrookNLP/musique
echo "Place 2Wiki / MuSiQue JSON(L) under data/raw/2wiki and data/raw/musique (official release pages)."
# Wikipedia snapshot (fixed): HF datasets 'wikimedia/wikipedia' config 20231101.en
