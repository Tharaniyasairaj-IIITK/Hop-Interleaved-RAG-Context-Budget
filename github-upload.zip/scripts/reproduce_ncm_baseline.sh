#!/usr/bin/env bash
# Phase 1 gate: reproduce an official NCM result (XSum) BEFORE any modification.
set -euo pipefail
cd third_party/ncm
pip install -r requirements.txt
python evaluate.py --config config/eval/xsum.yaml \
  --checkpoint-dir ../../artifacts/ncm-checkpoints/xsum \
  --data-dir ../../data/ncm_reproduction/xsum | tee ../../results/logs_ncm_xsum_repro.txt
# Record ROUGE-1/2/L and gen-PPL; compare with the NCM paper before proceeding.
