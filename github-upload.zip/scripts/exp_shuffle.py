#!/usr/bin/env python
"""Order-robustness test (tests Prop. 1 empirically): train each system once, evaluate on the original
hop-interleaved context order and on random permutations of the same passages. EM only (rank metrics are
undefined under shuffling)."""
import argparse, json, random, time
import numpy as np, torch
from gmrncm.data.synthetic import build_world
from gmrncm.pipeline import split, build_traces, make_features, SPECS
from gmrncm.model import GMRConceptGenerator, train
from gmrncm.baselines import NeuralPredictor
from gmrncm.grounding import ground_context
from gmrncm.schema import ABSTAIN
from gmrncm.text import exact_match

ap = argparse.ArgumentParser()
ap.add_argument("--seed", type=int, default=0); ap.add_argument("--n_questions", type=int, default=300)
ap.add_argument("--epochs", type=int, default=6); ap.add_argument("--n_perm", type=int, default=5)
ap.add_argument("--out", default="results/shuffle")
a = ap.parse_args()
torch.set_num_threads(1)
ex, corpus = build_world(a.n_questions, seed=a.seed)
tr, dv, te = split(ex, a.seed)
traces, by_id = build_traces(ex, corpus)
res = {}
for key in ["ref_multihop5", "gmr_full", "gmr_norankinv"]:
    spec = SPECS[key]
    torch.manual_seed(a.seed)
    m = GMRConceptGenerator(grounded=spec.grounded, hops=3)
    feats = make_features(tr, traces, by_id, "multihop", 5)
    t0 = time.time()
    train(m, feats, epochs=a.epochs, seed=a.seed, log=lambda s: None, rank_invariance=(key != "gmr_norankinv"), lam_cov=1.0 if spec.grounded else 0.0)
    pred = NeuralPredictor(m)
    def acc(shuffle_seed=None):
        rng = random.Random(shuffle_seed); em = []
        for e in te:
            if not e.answerable: continue
            ctx = ground_context(traces[e.id], by_id, 5, mode="multihop")
            if shuffle_seed is not None: rng.shuffle(ctx)
            em.append(exact_match(pred(e, ctx, spec)["prediction"], e.gold_answer))
        return float(np.mean(em))
    orig = acc(None); perms = [acc(1000 + i) for i in range(a.n_perm)]
    res[key] = {"orig": orig, "shuffled_mean": float(np.mean(perms)), "shuffled_min": float(np.min(perms)), "perms": perms,
                "n_test_answerable": sum(e.answerable for e in te), "train_s": time.time() - t0}
    print(a.seed, key, {k: round(v, 3) for k, v in res[key].items() if isinstance(v, float)}, flush=True)
import os; os.makedirs(a.out, exist_ok=True)
json.dump(res, open(f"{a.out}/seed{a.seed}.json", "w"), indent=1)
