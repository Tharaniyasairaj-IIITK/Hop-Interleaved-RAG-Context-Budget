#!/usr/bin/env bash
# Fetch the real 1,000-question HotpotQA / 2WikiMultihopQA / MuSiQue dev subsets + corpora (MIT repo, original data licences apply).
set -euo pipefail
DEST=${1:-data/real}
TMP=$(mktemp -d)
git clone --depth 1 --filter=blob:none --sparse https://github.com/OSU-NLP-Group/HippoRAG "$TMP/h" >/dev/null
git -C "$TMP/h" sparse-checkout set reproduce/dataset >/dev/null
mkdir -p "$DEST"
for f in hotpotqa 2wikimultihopqa musique; do cp "$TMP/h/reproduce/dataset/$f.json" "$TMP/h/reproduce/dataset/${f}_corpus.json" "$DEST/"; done
( cd "$DEST" && sha256sum *.json > SHA256SUMS )
echo "wrote $DEST"; cat "$DEST/SHA256SUMS"
