"""Tables for the Information Processing Letters manuscript (all numbers from results/real/*.json; baselines as reported by HippoRAG)."""
import json, numpy as np
from pathlib import Path
B = {d: json.load(open(f"results/real/bench_{d}.json"))["results"][d] for d in ("musique", "2wiki", "hotpotqa")}
DS = [("musique", "MuSiQue"), ("2wiki", "2Wiki"), ("hotpotqa", "HotpotQA")]
PUB = [("BM25 \\cite{robertson2009bm25}", [32.3,41.2,51.8,61.9,55.4,72.2]), ("Contriever \\cite{izacard2022contriever}", [34.8,46.6,46.6,57.5,57.2,75.5]),
       ("GTR \\cite{ni2022gtr}", [37.4,49.1,60.2,67.9,59.4,73.3]), ("ColBERTv2 \\cite{santhanam2022colbertv2}", [37.9,49.2,59.2,68.2,64.7,79.3]),
       ("HippoRAG (ColBERTv2) \\cite{gutierrez2024hipporag}", [40.9,51.9,70.7,89.1,60.5,77.7]), ("IRCoT + BM25 \\cite{trivedi2023ircot}", [34.2,44.7,61.2,75.6,65.6,79.0]),
       ("IRCoT + HippoRAG (ColBERTv2)", [45.3,57.6,75.8,93.9,67.0,83.0])]
avg = lambda v: [round(np.mean(v[0::2]), 1), round(np.mean(v[1::2]), 1)]
L = ["\\begin{tabular}{lcccccccc}", "\\toprule", " & \\multicolumn{2}{c}{MuSiQue} & \\multicolumn{2}{c}{2Wiki} & \\multicolumn{2}{c}{HotpotQA} & \\multicolumn{2}{c}{Average}\\\\",
     "Retriever & R@2 & R@5 & R@2 & R@5 & R@2 & R@5 & R@2 & R@5\\\\", "\\midrule", "\\multicolumn{9}{l}{\\emph{Reported baselines$^\\dagger$}}\\\\"]
for n, v in PUB: L.append(n + " & " + " & ".join(f"{x:.1f}" for x in v + avg(v)) + "\\\\")
L += ["\\midrule", "\\multicolumn{9}{l}{\\emph{Measured here (BM25 index, no neural component, no LLM)}}\\\\"]
for lab, key in [("Single-step BM25 (top-$k$)", "bm25_single"), ("Iterative, RRF-merged", "gmr_rrf_merged"), ("\\textbf{Iterative, hop-interleaved}", "gmr_hop_interleaved")]:
    v = [100 * B[d]["retrieval"][k][key] for d, _ in DS for k in ("R@2", "R@5")]
    L.append(lab + " & " + " & ".join(f"{x:.1f}" for x in v + avg(v)) + "\\\\")
L += ["\\bottomrule", "\\end{tabular}"]; Path("ipl/tables/retrieval.tex").write_text("\n".join(L))
S = json.load(open("results/real/distractor_summary.json"))
L = ["\\begin{tabular}{lrrrrrrr}", "\\toprule", "Dataset & Corpus & Pool & \\multicolumn{2}{c}{BM25 R@5} & \\multicolumn{2}{c}{Iterative R@5} & Gain\\\\", " & $n$ & $n'$ & $n$ & $n'$ & $n$ & $n'$ & $n'$ \\\\", "\\midrule"]
for d, nm in [("hotpotqa", "HotpotQA"), ("2wiki", "2Wiki"), ("musique", "MuSiQue")]:
    s = S[d]; n0 = {"hotpotqa": 9811, "2wiki": 6119, "musique": 11656}[d]; n1 = n0 + s["added"][-1]
    L.append(f"{nm} & {n0:,} & {n1:,} & {s['bm25'][0]:.1f} & {s['bm25'][-1]:.1f} & {s['gmr'][0]:.1f} & {s['gmr'][-1]:.1f} & {round(s['gmr'][-1],1)-round(s['bm25'][-1],1):+.1f}\\\\")
av = lambda k, i: np.mean([S[d][k][i] for d in S])
L += ["\\midrule", f"Average & & & {av('bm25',0):.1f} & {av('bm25',-1):.1f} & {av('gmr',0):.1f} & {av('gmr',-1):.1f} & {av('gmr',-1)-av('bm25',-1):+.1f}\\\\", "\\bottomrule", "\\end{tabular}"]
Path("ipl/tables/distractors.tex").write_text("\n".join(L).replace(",", "{,}") if False else "\n".join(L))
M = json.load(open("results/real/lemma_check.json"))
L = ["\\begin{tabular}{llccccc}", "\\toprule", "Dataset & $t$ & $B{=}3t$ & Premise holds & Full coverage (interleaved) & Full coverage (single step) & Violations\\\\", "\\midrule"]
for d, nm in [("hotpotqa", "HotpotQA"), ("2wiki", "2Wiki"), ("musique", "MuSiQue")]:
    for t in ("1", "2", "3"):
        r = M[d][t]; L.append(f"{nm if t=='1' else ''} & {t} & {r['B']} & {100*r['premise']:.1f} & {100*r['interleaved']:.1f} & {100*r['single_step']:.1f} & {r['violations']}\\\\")
    if d != "musique": L.append("\\addlinespace")
L += ["\\bottomrule", "\\end{tabular}"]; Path("ipl/tables/lemma.tex").write_text("\n".join(L))
print(open("ipl/tables/distractors.tex").read())
