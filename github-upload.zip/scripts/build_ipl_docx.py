#!/usr/bin/env python
"""Pandoc-friendly copy of ipl/main.tex (elsarticle -> article, tables inlined) -> ipl/paper.docx."""
import re, subprocess, os, sys
D = sys.argv[1] if len(sys.argv) > 1 else "ipl"
J = "Pattern Recognition Letters" if D == "prl" else "Information Processing Letters"
os.chdir(D)
s = open("main.tex").read()
s = re.sub(r"\\ifdefined\\REVIEW.*?\\fi\n", "\\\\documentclass{article}\\\\usepackage{graphicx,booktabs,amsmath,amssymb,amsthm,float,url}\n", s, count=1)
for pat in [r"\\usepackage\{lineno\}\n", r"\\modulolinenumbers.*\n", r"\\ifdefined\\REVIEW\\linenumbers\\fi\n", r"\\bibliographystyle\{[^}]*\}\n", r"%%.*\n"]:
    s = re.sub(pat, "", s)
s = re.sub(r"\\journal\{[^}]*\}\n", "", s)
s = re.sub(r"\\usepackage\{amsmath,amssymb,amsthm,booktabs,graphicx,float,algorithm,algpseudocode,url\}\n", "", s)
s = s.replace("\\usepackage[hidelinks]{hyperref}\n", "").replace("\\emergencystretch=2em\n", "")
# frontmatter
title = re.search(r"\\title\{(.*?)\}\n", s).group(1)
abstract = re.search(r"\\begin\{abstract\}(.*?)\\end\{abstract\}", s, re.S).group(1)
hl = re.search(r"\\begin\{highlights\}(.*?)\\end\{highlights\}", s, re.S).group(1).replace("\\item", "\\item")
kw = re.search(r"\\begin\{keyword\}\s*(.*?)\s*\\end\{keyword\}", s, re.S).group(1).replace("\\sep", ";")
front = ("\\title{%s}\\author{Anonymous Author(s)}\\date{@J@}\\maketitle\n"
         "\\begin{abstract}%s\\end{abstract}\n\\textbf{Highlights}\n\\begin{itemize}%s\\end{itemize}\n\\textbf{Keywords:} %s\n") % (title, abstract, hl, kw)
front = front.replace("@J@", J)
s = re.sub(r"\\begin\{frontmatter\}.*?\\end\{frontmatter\}\n", lambda m: front, s, flags=re.S)
# algorithm -> numbered list
a = s.index("\\begin{algorithm}"); b = s.index("\\end{algorithm}") + len("\\end{algorithm}")
alg = ("\\textbf{Algorithm 1: Hop-interleaved iterative retrieval.} Input: question $q$, scorer $s$, hops $H$, list length $K$, budget $B$.\n\\begin{enumerate}\n"
       "\\item $u_1\\leftarrow q$; $\\mathcal{C}\\leftarrow\\emptyset$.\n"
       "\\item For $h=1,\\dots,H$: $D_h\\leftarrow R_K(u_h)$ without duplicates; $E_h\\leftarrow\\mathrm{Ent}(D_h^{\\le3})\\setminus\\mathrm{Ent}(u_{\\le h})$; $u_{h+1}\\leftarrow q\\oplus E_h$ (Eq.~\\eqref{eq:hop}).\n"
       "\\item For depth $r=1,\\dots,K$ and hop $h=1,\\dots,H$ (in this order): if $|\\mathcal{C}|<B$ and the $r$-th passage of $D_h$ is not in $\\mathcal{C}$, add it to $\\mathcal{C}$.\n"
       "\\item Return $\\mathcal{C}$.\n\\end{enumerate}")
s = s[:a] + alg + s[b:]
s = s.replace("\\newtheorem{lemma}{Lemma}", "\\newtheorem{lemma}{Lemma}")
s = s.replace("[H]", "[h]").replace("[!t]", "[h]")
s = s.replace("\\resizebox{\\columnwidth}{!}{\\begin{tabular}", "\\begin{tabular}").replace("\\end{tabular}}", "\\end{tabular}")
s = re.sub(r"\\resizebox\{\\columnwidth\}\{!\}\{(\\input\{[^}]+\})\}", r"\1", s)
inline = lambda m: re.sub(r"\\addlinespace", "", re.sub(r"\\cmidrule(\([lr]+\))?\{[^}]*\}", "", open(m.group(1)).read())).replace("@{}", "")
s = re.sub(r"\\input\{(tables/[^}]+)\}", inline, s)
s = s.replace("\\small", "")
s = s.replace("figures/fig_recall_real.pdf", "figures/fig_recall_real.png")
s = s.replace("\\bibliographystyle{elsarticle-num}\n\\bibliography{refs}", "\\section*{References}\n::: {#refs}\n:::")
s = re.sub(r"\\bibliographystyle\{[^}]*\}\n\\bibliography\{[^}]*\}", "\\\\section*{References}\n::: {#refs}\n:::", s)
open("paper_pandoc.tex", "w").write(s)
subprocess.run("pandoc paper_pandoc.tex -f latex -t docx --citeproc --bibliography=refs.bib -o paper.docx --resource-path=.", shell=True, check=True)
os.remove("paper_pandoc.tex")
import docx; d = docx.Document("paper.docx"); print("docx: tables", len(d.tables), "images", len(d.inline_shapes))
