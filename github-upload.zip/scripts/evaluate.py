#!/usr/bin/env python
"""Run the full offline pipeline (all systems + ablations) and save metrics/predictions/traces."""
import argparse, json
from gmrncm.pipeline import run_all
from gmrncm.io_utils import save_run

ap = argparse.ArgumentParser()
ap.add_argument("--n_questions", type=int, default=300); ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--epochs", type=int, default=6); ap.add_argument("--budget", type=int, default=5)
ap.add_argument("--out", default="results/runs/smoke")
a = ap.parse_args()
res, rows, _ = run_all(a.n_questions, a.seed, a.budget, a.epochs, a.out, print)
for k in res:
    save_run(a.out, k, rows[k], res[k], vars(a))
print(json.dumps({k: {m: round(v, 3) for m, v in r.items() if isinstance(v, float)} for k, r in res.items()}, indent=1))
