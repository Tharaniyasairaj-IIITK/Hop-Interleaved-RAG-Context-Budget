# GMR-NCM: Grounded Multihop Retrieval for Next-Concept Modeling

Code, experiment notebook and paper source for **GMR-NCM**: iterative multihop retrieval + evidence-grounded
coarse concept states + rank-robust training + claim verification, with measurement of *Top-k evidence dependence*.

## Honest status
* **Measured here** (synthetic multihop world + official architecture with random weights): retrieval study, pipeline validation, order-robustness, feasibility. Everything is regenerated from scripts; figures/tables are built from saved result files.
* **Not measured here**: HotpotQA / 2Wiki / MuSiQue numbers, anything using released NCM weights, and anything using the Stanford pickle files (`xsum/passages.pickle`, `xsum/reference_summaries.pickle`, ...). Those hosts were unreachable, so the paper's benchmark tables show `--`. No number was estimated or copied.
* **Official NCM** (`src/gmrncm/ncm_official.py`): verified against the official *code* with a tiny random model (generate + loss/backward), not against released weights.
* **Stanford pickles** (`src/gmrncm/ncm_pickles.py`): restricted (code-execution-safe) loader, SHA-256 manifest script, tested on stand-in files with the same structure.
* Converters for HotpotQA / 2Wiki / MuSiQue are tested on small hand-written *format fixtures* (`data/fixtures/`), not real data.

## Quick start (offline, CPU)
```bash
pip install -e . && pip install torch pytest matplotlib
pytest -q tests
python scripts/evaluate.py --n_questions 300 --epochs 8 --out results/runs/smoke
python scripts/make_tables_figures.py --run results/runs/smoke --out paper/tables
jupyter nbconvert --to notebook --execute notebooks/gmr_ncm_experiments.ipynb
```

## Reproduce every measured result
```bash
python scripts/evaluate.py --seed 0 --out results/runs/smoke_s0     # also seeds 1, 2 -> smoke_s1, smoke_s2
for s in 0 1 2 3 4; do python scripts/exp_shuffle.py --seed $s; done
python scripts/exp_retrieval.py
python scripts/feasibility.py --repo third_party/ncm
python scripts/make_paper_tables.py && python scripts/make_all_figures.py && python scripts/build_docx.py
```
(`scripts/topk_analysis.py --run results/runs/smoke_sS --seed S` produces the k=3 dependence files used by the tables.)

## Full study
```bash
bash scripts/download_assets.sh            # NCM repo/checkpoints, HotpotQA (+ place 2Wiki/MuSiQue by hand)
bash scripts/reproduce_ncm_baseline.sh     # gate: reproduce an official NCM number first
python scripts/build_multihop_dataset.py --hotpot_train data/raw/hotpotqa/hotpot_train_v1.1.json \
       --hotpot_dev data/raw/hotpotqa/hotpot_dev_distractor_v1.json
python scripts/run_retrieval.py --questions data/processed/dev.jsonl --corpus data/processed/corpus.jsonl \
       --retriever dense:BAAI/bge-large-en-v1.5 --output data/interim/retrieval_candidates/dev_traces.jsonl
python scripts/run_ar_baseline.py --questions data/processed/dev.jsonl --corpus data/processed/corpus.jsonl \
       --traces data/interim/retrieval_candidates/dev_traces.jsonl --context_mode multihop --output outputs/predictions/llama_multihop5.jsonl
```
Note: HotpotQA's distractor files only contain ~10 paragraphs per question; for the open-domain setting build the
corpus from a fixed Wikipedia snapshot as described in the paper (Section 6).

## Layout
`src/gmrncm/` library - `scripts/` CLIs - `notebooks/` experiment notebook - `tests/` - `paper/` LaTeX source - `results/` run outputs.

## Paper
`paper/main.tex` uses `neurips_local.sty`, a **local approximation** of the NeurIPS layout. Before submitting, download the
official style file from the NeurIPS website, place it in `paper/`, and replace `\usepackage[preprint]{neurips_local}` with the official package.

## Real-data benchmark (added for the WWW short paper)
Real 1,000-question dev subsets of HotpotQA, 2WikiMultihopQA and MuSiQue with their corpora are fetched by
`bash scripts/download_real_data.sh data/real` (public MIT-licensed redistribution inside the HippoRAG repository; the
original dataset licences apply; SHA-256 sums are written to `data/real/SHA256SUMS`). Then:

    python scripts/run_real_benchmark.py --datasets hotpotqa --seeds 0,1,2 --epochs 8 --out results/real/bench_hotpotqa.json   # also 2wiki, musique
    python scripts/run_distractor_study.py --dataset hotpotqa    # also 2wiki, musique (natural-distractor scaling, ~10 min each)
    python scripts/make_short_tables.py && python scripts/make_short_figure.py && python scripts/build_short_docx.py
    cd short && latexmk -pdf main.tex       # 4-page ACM sigconf short paper (acmart generated from the official source)

Measured on real data: Recall@2/5 of single-step BM25 vs. GMR-NCM hop-interleaved retrieval, and EM/F1 of the
extractive reference reader (flat top-5, flat multihop-5, GMR variants, 3 seeds). Baseline scores in the paper
(BM25, Contriever, GTR, ColBERTv2, HippoRAG, IRCoT combinations) are *reported* numbers from the HippoRAG evaluation of the
same subsets, not re-run here; they use dense/LLM components and an LLM reader and are not protocol-matched.
Honest summary: retrieval Recall@5 improves (avg 61.2 -> 68.7); the grounded reader does NOT beat the flat control on real data.

Distractor study (real data): enlarging each dev corpus with passages of the other two datasets (up to 4.5x) lowers Recall@5 by
0.6-1.3 points for single-step BM25 and 1.2-2.4 points for GMR-NCM retrieval; the average advantage over BM25 stays at +6.8 (+7.5 without distractors).

## Information Processing Letters short communication (`ipl/`)

`ipl/main.tex` (standard Elsevier `elsarticle` submission template, default Elsevier two-column layout, 7 pages including the highlights page; line-numbered review layout: `cd ipl && pdflatex '\def\REVIEW{1}\input{main.tex}'`) contains the budget-constrained iterative retrieval
algorithm, the coverage lemma, the separation proposition, the order-invariance proposition and the real-data evaluation (HotpotQA, 2WikiMultihopQA, MuSiQue subsets).

```bash
bash scripts/download_real_data.sh                  # real subsets (HippoRAG repo, MIT)
python scripts/run_real_benchmark.py                # retrieval + reader results
python scripts/run_distractor_study.py              # distractor enlargement
python scripts/lemma_check.py                       # empirical check of Lemma 1
python scripts/make_short_figure.py                 # figure
python scripts/make_ipl_tables.py                   # ipl/tables/*.tex
cd ipl && pdflatex main && bibtex main && pdflatex main && pdflatex main
python scripts/build_ipl_docx.py                    # ipl/ipl.docx
pytest tests/test_interleave.py tests/test_separation.py
```
Baseline scores in the paper are reported values from the HippoRAG evaluation on the same subsets; they were not re-run.

## Pattern Recognition Letters version (`prl/`)

`prl/main.tex` is the same study recast for *Pattern Recognition Letters* (Elsevier `elsarticle`, two-column layout, 7 pages including highlights;
line-numbered review layout: `cd prl && pdflatex '\def\REVIEW{1}\input{main.tex}'`). DOCX: `python scripts/build_ipl_docx.py prl`.
