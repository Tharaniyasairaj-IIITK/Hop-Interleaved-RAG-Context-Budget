import os, pytest
REPO = os.environ.get("NCM_REPO", "/home/claude/hazyresearch/ncm")
pytest.importorskip("torch"); pytest.importorskip("omegaconf"); pytest.importorskip("hydra")
pytestmark = pytest.mark.skipif(not os.path.isdir(REPO), reason="official NCM repo not cloned (set NCM_REPO)")


def test_tiny_official_ncm_generate_and_loss():
    import torch
    from gmrncm.ncm_official import build_tiny_ncm, evidence_prefix_ids, teacher_forced_loss
    from gmrncm.schema import Passage
    vqvae, net, cfg = build_tiny_ncm(REPO)
    P, pad = net.prefix_len, int(cfg.prefix_pad_token_id)
    enc = lambda s: [(ord(c) % 250) + 1 for c in s]            # toy byte-ish tokenizer
    ctx = [Passage("p1", "Film A", "Film A was directed by Zed."), Passage("p2", "Zed", "Zed was born in Belmora.")]
    pre = torch.tensor([evidence_prefix_ids("Where was the director of Film A born?", ctx, enc, P, pad)])
    assert pre.shape == (1, P)
    net.eval()
    out = net.generate(None, pre, temperature=0.0, top_k=1, top_p=0.0)
    assert out.shape[1] == sum(net.levels)
    net.train()
    tgt = torch.randint(1, 250, (1, vqvae.context_length))
    loss, _ = teacher_forced_loss(net, vqvae, pre, tgt)
    loss.backward()
    assert torch.isfinite(loss)
