import numpy as np
from gmrncm.text import exact_match, f1_score
from gmrncm import metrics as M
from gmrncm.data.synthetic import build_world
from gmrncm.retrieval import BM25Retriever, rrf
from gmrncm.multihop import IterativeRetriever
from gmrncm.schema import Passage
from gmrncm.verifier import LexicalVerifier
from gmrncm.concepts import HashEmbedder, ResidualVQ


def test_em_f1():
    assert exact_match("The Paris", "paris") == 1.0
    assert 0 < f1_score("big red dog", "red dog") < 1


def test_topk_metrics():
    rows = [{"supported": True, "ranks": [1], "min_rank": 1}, {"supported": True, "ranks": [7], "min_rank": 7},
            {"supported": False, "ranks": [], "min_rank": None}]
    assert M.topk_claim_share(rows, 5) == 0.5
    assert M.topk_dependence(rows, 5) == 0.5
    assert abs(M.claim_precision(rows) - 2 / 3) < 1e-9


def test_rrf_and_bm25():
    ex, corpus = build_world(30, seed=1, n_noise=50)
    r = BM25Retriever(corpus)
    e = ex[0]
    top = [pid for pid, _ in r.search(e.question, 10)]
    assert any(corpus_p.title in e.gold_passage_titles for corpus_p in corpus if corpus_p.passage_id in top)
    assert rrf([["a", "b"], ["b", "c"]])[0][0] == "b"


def test_iterative_finds_bridge():
    ex, corpus = build_world(60, seed=2, n_noise=100, abstain_frac=0.0)
    it = IterativeRetriever(BM25Retriever(corpus), corpus, hops=3, per_hop_k=10)
    hit = 0
    for e in ex[:30]:
        tr = it.run(e.id, e.question).to_dict()
        got = {c["passage_id"] for c in tr["merged_candidates"]}
        gold = {f"wiki:{t.replace(' ', '_')}::0000" for t in e.gold_passage_titles}
        hit += gold <= got
    assert hit / 30 > 0.7


def test_verifier():
    v = LexicalVerifier(0.8)
    p = [Passage("p1", "A", "Zed Ashford was born in Belmora 3.")]
    assert v.verify("Zed Ashford was born in Belmora 3", p).supported
    assert not v.verify("Zed Ashford was born in Cindral 9", p).supported


def test_rvq_roundtrip_improves():
    X = np.random.default_rng(0).normal(size=(200, 16)).astype("float32")
    q = ResidualVQ(3, 16).fit(X)
    c = q.encode(X)
    e1 = ((X - q.decode(c, 1)) ** 2).mean(); e3 = ((X - q.decode(c, 3)) ** 2).mean()
    assert e3 < e1
