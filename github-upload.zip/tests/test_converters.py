from gmrncm.data.hotpot import convert_hotpot, convert_2wiki
from gmrncm.data.musique import convert_musique
from gmrncm.retrieval import BM25Retriever
from gmrncm.multihop import IterativeRetriever
F = "data/fixtures/"


def test_hotpot():
    ex, ps = convert_hotpot(F + "hotpot_format_fixture.json", "dev")
    assert len(ex) == 2 and ex[1].answer_type == "span" and ex[0].gold_passage_titles == ["Silent Harbor", "Alara Brightwater"]
    assert ex[0].distractor_passage_titles == ["Copper Skies"]


def test_2wiki_hops_from_evidences():
    ex, _ = convert_2wiki(F + "2wiki_format_fixture.json", "dev")
    assert ex[0].source_dataset == "2wiki" and ex[0].num_hops == 2 and ex[0].metadata["type"] == "compositional"


def test_musique_answerable_flag():
    ex, ps = convert_musique(F + "musique_format_fixture.jsonl", "dev")
    assert [e.answerable for e in ex] == [True, False] and ex[0].num_hops == 2
    assert ex[0].gold_passage_titles == ["Glass Meridian", "Wylan Fairbanks"]


def test_bridge_retrieval_on_musique_fixture():
    ex, ps = convert_musique(F + "musique_format_fixture.jsonl", "dev")
    tr = IterativeRetriever(BM25Retriever(ps), ps, hops=2, per_hop_k=3).run(ex[0].id, ex[0].question).to_dict()
    got = {c["passage_id"] for c in tr["merged_candidates"]}
    assert any("::1" in g for g in got)
