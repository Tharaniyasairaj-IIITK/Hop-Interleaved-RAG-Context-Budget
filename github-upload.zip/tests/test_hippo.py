import os, pytest
from gmrncm.data.hippo import load_hippo_subset

ROOT = "data/real"


@pytest.mark.skipif(not os.path.exists(f"{ROOT}/hotpotqa.json"), reason="run scripts/download_real_data.sh first")
@pytest.mark.parametrize("name", ["hotpotqa", "2wiki", "musique"])
def test_gold_passages_are_in_corpus(name):
    ex, corpus = load_hippo_subset(name, ROOT, limit=50)
    keys = {p.title for p in corpus}
    assert len(keys) == len(corpus)                      # keys are unique even when MuSiQue titles repeat
    assert all(set(e.gold_passage_titles) <= keys and len(e.gold_passage_titles) >= 2 for e in ex)
