from gmrncm.schema import Passage
from gmrncm.retrieval import BM25Retriever
from gmrncm.multihop import IterativeRetriever
from gmrncm.grounding import ground_context

Q = "Where was the founder of Zorbex born?"


def corpus(k):
    ps = [Passage("g1", "Zorbex", "Zorbex is a company that was founded by Alvin Kray in the year of the fox."),
          Passage("g2", "Alvin Kray", "Alvin Kray grew up in Tullamore, a small harbour town on a cold coast.")]
    return ps + [Passage(f"d{i}", f"Doc{i}", f"A famous founder number {i} started a company in a town long ago.") for i in range(k)]


def test_separation_proposition():
    for k in (1, 5, 20, 50):
        ps = corpus(k); r = BM25Retriever(ps)
        assert "g2" not in [p for p, _ in r.search(Q, k)]            # single-step top-k never contains g2 (no shared term)
        tr = IterativeRetriever(r, ps, hops=2, per_hop_k=10).run("q", Q).to_dict()
        ctx = {p.passage_id for p in ground_context(tr, {p.passage_id: p for p in ps}, 4, "multihop")}
        assert {"g1", "g2"} <= ctx                                    # iterative retrieval with B = H*t = 4 covers both
