import pickle, pytest, os
from gmrncm.ncm_pickles import load_pickle_safe, inspect_pickle, load_xsum_pair, xsum_distractors


def _mk(tmp_path):
    p, r = tmp_path / "passages.pickle", tmp_path / "reference_summaries.pickle"
    pickle.dump([f"BBC article {i} " + "word " * 300 for i in range(5)], open(p, "wb"))
    pickle.dump([f"summary {i}" for i in range(5)], open(r, "wb"))
    return p, r


def test_roundtrip_and_inspect(tmp_path):
    p, r = _mk(tmp_path)
    assert inspect_pickle(p)["n"] == 5 and inspect_pickle(p)["item_kind"] == "str"
    items, refs = load_xsum_pair(p, r, 3)
    assert len(items) == len(refs) == 3
    assert len(xsum_distractors(p, 4, 50)) == 4


def test_blocks_code_execution(tmp_path):
    class Evil:
        def __reduce__(self):
            return (os.system, ("echo pwned > " + str(tmp_path / "pwned"),))
    bad = tmp_path / "bad.pickle"; pickle.dump(Evil(), open(bad, "wb"))
    with pytest.raises(pickle.UnpicklingError):
        load_pickle_safe(bad)
    assert not (tmp_path / "pwned").exists()
