import pytest
torch = pytest.importorskip("torch")
from gmrncm.pipeline import run_all


def test_end_to_end_tiny(tmp_path):
    res, rows, _ = run_all(n_questions=60, epochs=2, out_dir=str(tmp_path), log=lambda s: None,
                           systems=["closed_book", "ref_top5", "gmr_full"])
    assert set(res) == {"closed_book", "ref_top5", "gmr_full"}
    assert 0.0 <= res["gmr_full"]["em"] <= 1.0


def test_targets_extractable():
    from gmrncm.data.synthetic import build_world
    from gmrncm.pipeline import build_traces, make_features
    ex, corpus = build_world(60, seed=3, n_noise=50, abstain_frac=0.0)
    traces, by = build_traces(ex, corpus)
    feats = make_features(ex, traces, by, "multihop", 5)
    assert sum(f["target"] >= 0 for f in feats) / len(feats) > 0.8
