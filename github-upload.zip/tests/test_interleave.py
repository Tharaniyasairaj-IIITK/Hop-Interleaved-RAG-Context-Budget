import random
from gmrncm.grounding import ground_context
from gmrncm.schema import Passage


def _trace(lists):
    return {"hops": [{"retrieved": [{"passage_id": p} for p in l]} for l in lists]}


def test_interleaving_coverage_lemma_random():
    rng = random.Random(0)
    for _ in range(300):
        H, n = rng.randint(1, 4), 30
        lists = [rng.sample(range(n), rng.randint(1, 12)) for _ in range(H)]
        by_id = {i: Passage(i, str(i), "x") for i in range(n)}
        for t in range(1, 5):
            sel = {p.passage_id for p in ground_context(_trace(lists), by_id, H * t, "multihop")}
            assert all(set(l[:t]) <= sel for l in lists)          # every top-t item of every hop list is selected
        assert len(ground_context(_trace(lists), by_id, 5, "multihop")) <= 5
