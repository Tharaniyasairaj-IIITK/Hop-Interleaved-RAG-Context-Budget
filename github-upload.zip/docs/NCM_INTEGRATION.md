# Official NCM integration

`src/gmrncm/ncm_official.py` is written against the real code of https://github.com/HazyResearch/ncm
(clone it to `third_party/ncm` or set `NCM_REPO`). `tests/test_ncm_official.py` instantiates a tiny random model
with the official classes (VQVAE + NextConceptTransformer), generates from an evidence prefix and back-propagates a
teacher-forced loss. **Not verified:** behaviour with the released weights (unreachable when this package was built).

Key facts from the official code/config: conditioning is a fixed-length raw-token *prefix* (XSum: 512), target
48 tokens in 9 levels, 4096-code books, level-0 queries, block-diagonal attention, RoPE.

Steps for the full study
1. `bash scripts/download_assets.sh`; `bash scripts/reproduce_ncm_baseline.sh` (gate).
2. `load_official_ncm(repo, config.yaml, ckpt_dir)` -> (tokenizer, generator, cfg).
3. Build prefixes with `evidence_prefix_ids` (hop/source markers, per-passage token share).
4. Fine-tune with LoRA on `teacher_forced_loss` (+ coverage / rank-invariance terms computed from prefix attention; see `model.loss_fn` for the reference form).
5. Decode with `net.generate(None, prefix, ...)`, decode codes with `tokenizer.decode`, then evaluate with `systems.evaluate_system`.
