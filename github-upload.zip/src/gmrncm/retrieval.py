"""Retrievers (BM25 offline, dense optional) and reciprocal rank fusion."""
from __future__ import annotations
import math, collections
import numpy as np
from .schema import Passage
from .text import tokenize


class BM25Retriever:
    """Self-contained Okapi BM25 so the whole pipeline runs offline."""

    def __init__(self, passages: list[Passage], k1: float = 1.2, b: float = 0.75):
        self.passages = passages
        self.k1, self.b = k1, b
        self.docs = [tokenize(p.title + " " + p.text) for p in passages]
        self.dl = np.array([len(d) for d in self.docs], dtype=np.float32)
        self.avgdl = float(self.dl.mean()) if len(self.dl) else 1.0
        self.df = collections.Counter()
        self.inv: dict[str, list[tuple[int, int]]] = collections.defaultdict(list)
        for i, d in enumerate(self.docs):
            for t, c in collections.Counter(d).items():
                self.df[t] += 1
                self.inv[t].append((i, c))
        self.N = len(passages)

    def _idf(self, t):
        n = self.df.get(t, 0)
        return math.log(1 + (self.N - n + 0.5) / (n + 0.5))

    def search(self, query: str, k: int = 20) -> list[tuple[str, float]]:
        scores = np.zeros(self.N, dtype=np.float32)
        for t in set(tokenize(query)):
            if t not in self.inv:
                continue
            idf = self._idf(t)
            for i, c in self.inv[t]:
                denom = c + self.k1 * (1 - self.b + self.b * self.dl[i] / self.avgdl)
                scores[i] += idf * c * (self.k1 + 1) / denom
        k = min(k, self.N)
        top = np.argpartition(-scores, k - 1)[:k]
        top = top[np.argsort(-scores[top])]
        return [(self.passages[i].passage_id, float(scores[i])) for i in top if scores[i] > 0]


class DenseRetriever:
    """Optional dense retriever (BGE/E5/Contriever) using sentence-transformers + FAISS."""

    def __init__(self, passages: list[Passage], model: str = "BAAI/bge-large-en-v1.5", batch_size: int = 256):
        from sentence_transformers import SentenceTransformer  # lazy
        import faiss
        self.passages = passages
        self.enc = SentenceTransformer(model)
        emb = self.enc.encode([p.title + ". " + p.text for p in passages], batch_size=batch_size,
                              normalize_embeddings=True, show_progress_bar=True).astype("float32")
        self.index = faiss.IndexFlatIP(emb.shape[1])
        self.index.add(emb)

    def search(self, query: str, k: int = 20):
        q = self.enc.encode([query], normalize_embeddings=True).astype("float32")
        s, idx = self.index.search(q, k)
        return [(self.passages[i].passage_id, float(sc)) for sc, i in zip(s[0], idx[0]) if i >= 0]


def rrf(rankings: list[list[str]], k: int = 60) -> list[tuple[str, float]]:
    """Reciprocal rank fusion over several ranked id lists."""
    sc: dict[str, float] = collections.defaultdict(float)
    for r in rankings:
        for rank, pid in enumerate(r, start=1):
            sc[pid] += 1.0 / (k + rank)
    return sorted(sc.items(), key=lambda x: -x[1])
