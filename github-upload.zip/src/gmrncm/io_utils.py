import json, os, platform, subprocess, sys, time
from pathlib import Path


def env_info():
    info = {"python": sys.version.split()[0], "platform": platform.platform(), "time": time.strftime("%Y-%m-%d %H:%M:%S")}
    try:
        import torch
        info["torch"] = torch.__version__
        info["cuda"] = torch.cuda.is_available()
        if info["cuda"]:
            info["gpu"] = torch.cuda.get_device_name(0)
    except Exception:
        info["torch"] = None
    try:
        info["git_commit"] = subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        info["git_commit"] = None
    return info


def save_run(out_dir, name, rows, summary, config):
    d = Path(out_dir); (d / "predictions").mkdir(parents=True, exist_ok=True); (d / "metrics").mkdir(exist_ok=True)
    with open(d / "predictions" / f"{name}.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r, default=float) + "\n")
    json.dump({"summary": summary, "config": config, "env": env_info()}, open(d / "metrics" / f"{name}.json", "w"),
              indent=2, default=float)
