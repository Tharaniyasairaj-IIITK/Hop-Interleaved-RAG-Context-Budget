"""Query decomposition + iterative multihop retrieval with full traces (Phase 4 logging format)."""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from .schema import Passage
from .retrieval import rrf
from .text import content_tokens

_CAP = re.compile(r"\b([A-Z][a-zA-Z0-9\-']+(?:\s+[A-Z][a-zA-Z0-9\-']+)*)\b")


def extract_entities(text: str, exclude: set[str] | None = None) -> list[str]:
    exclude = exclude or set()
    seen, out = set(), []
    for m in _CAP.findall(text):
        if m.lower() in {"the", "a", "an", "who", "what", "when", "where", "which", "how"}:
            continue
        if m not in seen and m not in exclude:
            seen.add(m); out.append(m)
    return out


class RuleDecomposer:
    """Light rule-based decomposition (comparison / bridge). Swap for an LLM via `LLMDecomposer`."""

    def decompose(self, question: str) -> list[str]:
        q = question.strip().rstrip("?")
        m = re.match(r"(?i)^(?:which|who|what)\b.*?\b(older|younger|born first|earlier|later|larger|smaller)\b.*?,?\s*(.+?)\s+or\s+(.+)$", q)
        if m:
            return [question, f"{m.group(2)}", f"{m.group(3)}"]
        return [question]


class LLMDecomposer:
    """Hook: pass any callable `generate(prompt)->str` (e.g. a Llama-3.1 wrapper)."""

    def __init__(self, generate):
        self.generate = generate

    def decompose(self, question: str) -> list[str]:
        out = self.generate("Decompose into at most 3 sub-questions, one per line:\n" + question)
        subs = [l.strip("-• 0123456789.").strip() for l in out.splitlines() if l.strip()]
        return subs[:3] or [question]


@dataclass
class HopRecord:
    hop: int
    query: str
    retrieved: list  # [{"passage_id","rank","score"}]


@dataclass
class Trace:
    id: str
    hops: list[HopRecord] = field(default_factory=list)
    merged_candidates: list = field(default_factory=list)

    def to_dict(self):
        return {"id": self.id,
                "hops": [h.__dict__ for h in self.hops],
                "merged_candidates": self.merged_candidates}


class IterativeRetriever:
    """Hop 1: question. Hop h>1: query built from entities newly surfaced in hop h-1
    (optionally prefixed by sub-question / coarse-plan text). Merge with RRF."""

    def __init__(self, retriever, passages: list[Passage], hops: int = 2, per_hop_k: int = 10,
                 decomposer=None, use_subquestions: bool = True):
        self.r, self.by_id = retriever, {p.passage_id: p for p in passages}
        self.hops, self.per_hop_k = hops, per_hop_k
        self.dec = decomposer or RuleDecomposer()
        self.use_sub = use_subquestions

    def run(self, qid: str, question: str) -> Trace:
        tr = Trace(qid)
        subs = self.dec.decompose(question) if self.use_sub else [question]
        queries = [question]
        seen_pids: set[str] = set()
        known_ents: set[str] = set(extract_entities(question))
        rankings = []
        for h in range(1, self.hops + 1):
            qs = [queries[-1]] if h > 1 else [question] + subs[1:]
            hop_rank, rec = [], []
            for q in qs:
                for rank, (pid, sc) in enumerate(self.r.search(q, self.per_hop_k), start=1):
                    rec.append({"passage_id": pid, "rank": rank, "score": sc, "query": q})
                    hop_rank.append(pid)
            tr.hops.append(HopRecord(h, " || ".join(qs), rec))
            rankings.append(list(dict.fromkeys(hop_rank)))
            # next query: entities newly surfaced in the top-3 passages of this hop (bridge entities)
            new_ents = []
            for pid in rankings[-1][:3]:
                p = self.by_id[pid]
                if pid in seen_pids:
                    continue
                seen_pids.add(pid)
                new_ents += [e for e in extract_entities(p.text, known_ents) if e.lower() not in p.title.lower()]
            new_ents = list(dict.fromkeys(new_ents))[:4]
            known_ents |= set(new_ents)
            queries.append((" ".join(new_ents) + " " + question) if new_ents else question)
        tr.merged_candidates = [{"passage_id": p, "rrf_score": s} for p, s in rrf(rankings)]
        return tr
