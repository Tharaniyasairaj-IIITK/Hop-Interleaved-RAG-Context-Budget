"""Integration with the official Hazy Research NCM code (https://github.com/HazyResearch/ncm, MIT licence).

Verified against the released *code* (generator, VQ-VAE, multiscale residual VQ) by instantiating a tiny
randomly initialised model on CPU: prefix-conditioned `generate`, and a teacher-forced loss with backward.
NOT verified against released *weights* (Hugging Face is unreachable from the authoring sandbox).

Facts read from the official code/config (xsum.yaml) that shape GMR-NCM:
  * conditioning = a fixed-length *prefix* of raw GPT-2 BPE tokens (XSum: 512), padded with a pad id and masked;
    target levels attend to the prefix; positions inside a level are generated in parallel.
  * XSum target: 48 tokens, 9 levels with lengths 4,6,10,14,20,26,32,40,48, 4096-code books, query_level0=True.
  => evidence is serialised into the prefix (budget ~512 tokens ~ 3-5 passages); answers must be short.
"""
from __future__ import annotations
import sys
from pathlib import Path


def add_ncm_to_path(repo: str):
    p = str(Path(repo).resolve())
    if p not in sys.path:
        sys.path.insert(0, p)


def build_tiny_ncm(repo: str, levels=(2, 4, 8), V=64, D=32, in_vocab=300, ctx=8, prefix_len=48):
    """Randomly initialised, CPU-sized NCM with the same structure as the released XSum config."""
    add_ncm_to_path(repo)
    from omegaconf import OmegaConf
    from models.vqvae import VQVAE
    from models.next_concept import NextConceptTransformer
    n = len(levels)
    vq_cfg = OmegaConf.create({"clss": "multiscale_residual_vector_quantizer", "decay": 0.99, "epsilon": 1e-5,
                               "commitment_cost": 0.25,
                               "quant_resi": {"enabled": True, "ratio": 0.5, "share_mode": 0, "learnable_ratio": False},
                               "levels": {"use_manual_levels": True, "manual_levels": list(levels)}})
    vqvae = VQVAE(in_vocab_size=in_vocab, context_length=ctx, embed_dim=D, vqvae_vocab_size=[V] * n, n_layers=2,
                  vector_quantizer_config=vq_cfg, compression_factor=1, dropout=0.0)
    cfg = OmegaConf.create({"n_layer": 2, "n_head": 2, "bias": True, "dropout": 0.0, "n_embd": 64,
                            "context_length": prefix_len + ctx, "prefix_len": prefix_len, "raw_token_prefix": True,
                            "prefix_pad_token_id": in_vocab - 1, "vocab_size": [V] * n, "predict_level0": False,
                            "attn_pattern": "block_diagonal", "use_positional_encoding": True, "use_level_encoding": True,
                            "use_rope": True, "rope_base": 10000, "use_qk_norm": True, "ctx_encoder": {"enabled": False},
                            "use_flex_attention": False, "query_level0": True, "tie_heads_to_codebook": True,
                            "tie_heads_learn_scale": True})
    net = NextConceptTransformer(vqvae_local=vqvae, config=cfg)
    return vqvae, net, cfg


def load_official_ncm(repo: str, config_yaml: str, checkpoint_dir: str, device="cuda"):  # needs released weights
    """Mirror of scripts/eval_shard.py model construction."""
    add_ncm_to_path(repo)
    import os, torch
    from omegaconf import OmegaConf
    from tokenization.vqvae_tokenizer import VQVAETokenizer
    from models.next_concept import NextConceptTransformer
    CFG = OmegaConf.load(config_yaml)
    CFG.tokenizer.vqvae.checkpoint_path = os.path.join(checkpoint_dir, CFG.checkpoints.tokenizer)
    tk = VQVAETokenizer.from_config(CFG.tokenizer)
    tk.vqvae = tk.vqvae.to(device).eval()
    net = NextConceptTransformer(vqvae_local=tk.vqvae, config=CFG.model).to(device)
    sd = torch.load(os.path.join(checkpoint_dir, CFG.checkpoints.generator), map_location="cpu", weights_only=False)
    net.load_state_dict(sd["model"], strict=True)
    return tk, net.eval(), CFG


def evidence_prefix_ids(question: str, context, bpe_encode, prefix_len: int, pad_id: int, max_per_passage: int | None = None):
    """Serialise question + hop-tagged, source-tagged passages into the fixed-length NCM prefix.
    Markers '[S<i>|H<h>]' carry source identity and hop (zero extra parameters); truncated per passage so every
    passage keeps a share of the prefix instead of the first one consuming it (anti top-k collapse)."""
    q = bpe_encode(f"Question: {question}\nEvidence:\n")
    room = prefix_len - len(q) - 2
    k = max(1, len(context))
    per = max_per_passage or max(8, room // k)
    ids = list(q)
    for i, p in enumerate(context):
        hop = getattr(p, "hop", 1) if not isinstance(p, dict) else p.get("hop", 1)
        ids += bpe_encode(f"[S{i+1}|H{hop}] {p.title}: {p.text}")[:per]
    ids = ids[: prefix_len - 1] + bpe_encode("\nAnswer:")[:1]
    return (ids + [pad_id] * prefix_len)[:prefix_len]


def teacher_forced_loss(net, vqvae, prefix_ids, target_ids):
    """Cross-entropy over all level codes for a (prefix, target-text) pair. Mirrors forward()/generate() input
    construction for raw_token_prefix models: prefix embedding = vqvae.encoder.wte(prefix_ids)."""
    import torch
    import torch.nn.functional as F
    with torch.no_grad():
        x_t, idx_fine = vqvae.get_ncm_inputs(target_ids)       # inputs for levels>=1 and their code targets
        idx = vqvae.encode(target_ids)                          # all levels (level 0 included)
        z_prefix = vqvae.encoder.wte(prefix_ids)[:, : net.prefix_len, :]
    if net.query_level0:
        q0 = net.build_l0_query_input(prefix_ids.size(0), z_prefix.dtype)
        x_t = torch.cat([q0, x_t], dim=1) if x_t.size(1) == net.L - net.levels[0] else x_t
        tgt = idx
    else:
        tgt = idx_fine
    pm = prefix_ids[:, : net.prefix_len] == net.prefix_pad_id if net.prefix_pad_id is not None else None
    logits = net(torch.cat([z_prefix, x_t], dim=1), prefix_pad_mask=pm)
    return F.cross_entropy(logits.reshape(-1, logits.size(-1)), tgt.reshape(-1)), logits
