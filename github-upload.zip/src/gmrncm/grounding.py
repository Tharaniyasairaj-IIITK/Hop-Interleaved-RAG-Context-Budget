"""Evidence grounding: attach retrieved passages / entities / source IDs to coarse concept states."""
from __future__ import annotations
from dataclasses import dataclass, field
from .schema import Passage
from .multihop import extract_entities


@dataclass
class GroundedConcept:
    level: str                  # "coarse" | "fine"
    codes: list                 # hierarchical concept codes
    source_ids: list            # passage ids supporting this concept
    entities: list = field(default_factory=list)
    hop: int = 1


def ground_context(trace, by_id: dict, budget: int, mode: str = "multihop", round_robin: bool = True):
    """Select `budget` passages. mode='top_k' -> hop-1 ranking only (the standard RAG baseline).
    mode='multihop' -> hop-interleaved selection so each hop contributes (reduces top-k collapse)."""
    if mode == "top_k":
        ids = [r["passage_id"] for r in trace["hops"][0]["retrieved"]]
        ids = list(dict.fromkeys(ids))[:budget]
        return [by_id[i] for i in ids]
    per_hop = [list(dict.fromkeys(r["passage_id"] for r in h["retrieved"])) for h in trace["hops"]]
    out, seen = [], set()
    depth = 0
    while len(out) < budget and any(depth < len(p) for p in per_hop):
        for p in per_hop:
            if depth < len(p) and p[depth] not in seen and len(out) < budget:
                seen.add(p[depth]); out.append(p[depth])
        depth += 1
    return [by_id[i] for i in out]


def attach_evidence(codes, context: list[Passage], hop_of: dict | None = None, level="coarse") -> GroundedConcept:
    ents = []
    for p in context:
        ents += extract_entities(p.title)
    return GroundedConcept(level, list(map(int, codes)), [p.passage_id for p in context],
                           list(dict.fromkeys(ents)), hop=max((hop_of or {}).values(), default=1))
