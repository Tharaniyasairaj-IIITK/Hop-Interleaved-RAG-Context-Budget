"""Predictors that plug into systems.evaluate_system."""
from __future__ import annotations
import collections, time
from .schema import ABSTAIN
from .text import normalize_answer


class MajorityPrior:
    """Closed-book reference: predicts the most frequent training answer (no evidence)."""

    def __init__(self, train_examples):
        c = collections.Counter(normalize_answer(e.gold_answer) for e in train_examples if e.answerable)
        self.ans = c.most_common(1)[0][0] if c else ""

    def __call__(self, ex, ctx, spec):
        return {"prediction": self.ans, "cited_ids": [], "claims": []}


class NeuralPredictor:
    """Wraps GMRConceptGenerator: returns prediction, cited passages (routing top mass) and claims."""

    def __init__(self, model, hops_claims: int = 3):
        self.model, self.hc = model, hops_claims

    def _loo(self, ex, ctx, pred, f):
        import torch
        from .model import featurize
        if pred == ABSTAIN or pred not in f["spans"]:
            return [p.passage_id for p in ctx[: self.hc]]
        with torch.no_grad():
            p_full = torch.softmax(self.model(f)["logits"], 0)[f["spans"].index(pred)]
            drops = []
            for j in range(len(ctx)):
                f2 = featurize(ex.question, ctx[:j] + ctx[j + 1:])
                if pred in f2["spans"]:
                    pj = torch.softmax(self.model(f2)["logits"], 0)[f2["spans"].index(pred)]
                else:
                    pj = torch.tensor(0.0)
                drops.append(float(p_full - pj))
        order = sorted(range(len(ctx)), key=lambda j: -drops[j])[: self.hc]
        return [ctx[j].passage_id for j in order]

    def __call__(self, ex, ctx, spec):
        from .model import featurize, predict
        t0 = time.perf_counter()
        f = featurize(ex.question, ctx)
        pred, out = predict(self.model, f)
        alpha = out["alpha"]
        order = alpha.argsort(descending=True).tolist()
        cited, claims = [], []
        if self.model.grounded:
            for a in out["alphas"]:                          # one claim per hop = argmax routed passage
                j = int(a.argmax())
                if ctx[j].passage_id not in cited:
                    cited.append(ctx[j].passage_id)
                    claims.append(ctx[j].text.split(". ")[-1].strip().rstrip(".") + ".")
        else:  # flat reader has no routing: leave-one-out attribution (drop in prob. of the predicted span)
            cited = self._loo(ex, ctx, pred, f)
            claims = [ctx_by[c].text.split(". ")[-1].strip().rstrip(".") + "." for c in cited for ctx_by in [{p.passage_id: p for p in ctx}]]
        # final-answer claim: must appear in some context passage
        if pred != ABSTAIN:
            claims.append(pred)
        return {"prediction": pred, "cited_ids": cited, "claims": claims,
                "tokens_generated": len(pred.split()) + len(claims), "overhead_ms": (time.perf_counter() - t0) * 0}
