"""System registry and per-example evaluation. Every system gets identical retriever, corpus, passage budget."""
from __future__ import annotations
import time
from dataclasses import dataclass
from .schema import Example, Passage, ABSTAIN
from .grounding import ground_context
from .verifier import LexicalVerifier
from . import metrics as M


@dataclass
class SystemSpec:
    name: str
    context_mode: str          # closed_book | top_k | multihop
    grounded: bool = False     # evidence attached to concept states (hop routing)
    verify: bool = False       # claim-level verification / abstention
    backend: str = "reference"  # reference | ncm | ar | dlm


def make_claims(example, pred, context, by_title):
    """Atomic claims from the prediction + cited reasoning. For the reference generator we render the
    reasoning chain implied by routing (one claim per routed passage + final answer sentence)."""
    return []


def evaluate_system(spec: SystemSpec, examples: list[Example], traces: dict, by_id: dict, predictor,
                    budget: int = 5, verifier=None, tau_abstain: float | None = None):
    """predictor(example, context, spec) -> dict(prediction, cited_ids, claims, tokens_generated)."""
    verifier = verifier or LexicalVerifier()
    rows = []
    for ex in examples:
        t0 = time.perf_counter()
        tr = traces[ex.id]
        if spec.context_mode == "closed_book":
            ctx = []
        else:
            ctx = ground_context(tr, by_id, budget, mode=spec.context_mode)
        out = predictor(ex, ctx, spec)
        pred = out["prediction"]
        claims = out.get("claims", [])
        if spec.verify and claims:
            tab = M.claim_support_table(claims, ctx, verifier)
            if not all(r["supported"] for r in tab[-1:]):  # final-answer claim unsupported -> abstain
                pred = ABSTAIN
            out["prediction"] = pred
        lat = (time.perf_counter() - t0) * 1000 + out.get("overhead_ms", 0.0)
        tab = M.claim_support_table(claims, ctx, verifier) if claims else []
        titles_ctx = [p.title for p in ctx]
        cited = [by_id[i].title for i in out.get("cited_ids", []) if i in by_id]
        em, f1 = (M.answer_metrics(pred, ex.gold_answer) if ex.answerable else (float(pred == ABSTAIN),) * 2)
        gpos = [i for i, p in enumerate(ctx) if p.title in set(ex.gold_passage_titles)]
        top5_excess = M.excess_topk(tab, [i + 1 for i in gpos], 5) if tab and gpos else float("nan")
        rows.append({
            "id": ex.id, "system": spec.name, "context_mode": f"{spec.context_mode}_{budget}", "prediction": pred,
            "gold": ex.gold_answer, "answerable": ex.answerable, "num_hops": ex.num_hops,
            "em": em, "f1": f1,
            "claim_precision": M.claim_precision(tab) if tab else float("nan"),
            "evidence_recall": M.evidence_recall(ex.gold_passage_titles, titles_ctx),
            "hop_completion": M.hop_completion(ex.gold_passage_titles, cited) if cited else 0.0,
            "top5_claim_share": M.topk_claim_share(tab, 5) if tab else float("nan"),
            "top1_claim_share": M.topk_claim_share(tab, 1) if tab else float("nan"),
            "top5_dependence": M.topk_dependence(tab, 5) if tab else float("nan"),
            "top5_excess_dep": top5_excess,
            "abstention_acc": M.abstention_correct(pred, ex.answerable),
            "latency_ms": lat, "tokens_generated": out.get("tokens_generated", len(pred.split())),
            "cited_passage_ids": out.get("cited_ids", []), "generated_reasoning": claims,
            "gold_positions": gpos, "context_len": len(ctx),
            "retrieval_trace": f"outputs/retrieval_traces/{ex.id}.json",
        })
    return rows
