"""GMR concept generator (reference implementation, PyTorch).

A compact coarse-to-fine, evidence-grounded generator that mirrors the GMR-NCM factorisation
    p(y | q, C) = sum_z p(z_1..z_L | q, C) p(y | z_1..z_L, C)
* coarse levels  z_1..z_{L-1}: hop-wise evidence *routing* states (which passages carry the next reasoning step),
  quantised by a residual VQ so they are discrete concept codes that can be logged and attached to source IDs;
* fine level     y: pointer distribution over candidate answer spans mined from the evidence (+ abstain).
The released NCM generator is task-specific; see ncm_wrapper.py for plugging the official tokenizer/generator in.
"""
from __future__ import annotations
import hashlib, random
import numpy as np
import torch, torch.nn as nn, torch.nn.functional as F
from .multihop import extract_entities
from .text import tokenize
from .schema import ABSTAIN

V = 8192


def hid(tok: str) -> int:
    return int.from_bytes(hashlib.md5(tok.encode()).digest()[:4], "little") % (V - 2) + 2


def ids(text: str, maxlen: int):
    t = [hid(x) for x in tokenize(text)][:maxlen]
    return t + [0] * (maxlen - len(t))


_YEAR = __import__("re").compile(r"\b(1[0-9]{3}|20[0-9]{2})\b")


YESNO_CANDIDATES = False  # real-data runs add yes/no candidates for polar questions (HotpotQA comparison questions)
_POLAR = __import__('re').compile(r'^(is|are|was|were|do|does|did|can|could|has|have|had|will|would)\b', __import__('re').I)


def mine_candidates(question: str, context):
    """Candidate answer spans: capitalised phrases / years in evidence and question, with left context."""
    cands, seen = [], set()
    for pi, p in enumerate(context):
        text = p.text
        for m in list(__import__("re").finditer(r"[A-Z][a-zA-Z0-9\-']*(?:\s+(?:[A-Z][a-zA-Z0-9\-']*|[0-9]+))*", text)) + list(_YEAR.finditer(text)):
            span = m.group(0)
            if span.lower() in {"the", "a", "an"} or span in seen:
                continue
            left = " ".join(tokenize(text[: m.start()])[-4:])
            seen.add(span)
            cands.append({"span": span, "left": left, "passage": pi})
    for e in extract_entities(question):
        if e not in seen:
            seen.add(e); cands.append({"span": e, "left": "question", "passage": -1})
    if YESNO_CANDIDATES and _POLAR.match(question.strip()):
        cands += [{"span": "yes", "left": "question", "passage": -1}, {"span": "no", "left": "question", "passage": -1}]
    return cands


def featurize(question, context, gold_titles=(), answer=None, answerable=True, max_q=24, max_p=48, max_c=96):
    cands = mine_candidates(question, context)[:max_c]
    f = {
        "q": torch.tensor(ids(question, max_q)),
        "p": torch.tensor([ids(p.title + " " + p.text, max_p) for p in context]),
        "c_span": torch.tensor([ids(c["span"], 6) for c in cands] or [[0] * 6]),
        "c_left": torch.tensor([ids(c["left"], 4) for c in cands] or [[0] * 4]),
        "c_pas": torch.tensor([c["passage"] for c in cands] or [-1]),
        "gold_pas": torch.tensor([float(p.title in set(gold_titles)) for p in context]),
        "spans": [c["span"] for c in cands],
        "answerable": answerable,
    }
    tgt = -1
    if answer is not None and answerable:
        from .text import normalize_answer
        for i, c in enumerate(cands):
            if normalize_answer(c["span"]) == normalize_answer(answer):
                tgt = i; break
    f["target"] = tgt  # -1 => answer not extractable; (answerable=False => abstain index handled in loss)
    return f


class ResidualVQLayer(nn.Module):
    def __init__(self, d, K=32, L=2):
        super().__init__()
        self.cb = nn.ParameterList([nn.Parameter(torch.randn(K, d) * 0.1) for _ in range(L)])

    def forward(self, x):
        r, q, codes, commit = x, 0, [], 0.0
        for cb in self.cb:
            idx = torch.cdist(r, cb).argmin(-1)
            e = cb[idx]
            commit = commit + F.mse_loss(e, r.detach()) + 0.25 * F.mse_loss(r, e.detach())
            q = q + e; r = r - e.detach(); codes.append(idx)
        return x + (q - x).detach(), torch.stack(codes, -1), commit  # straight-through


class GMRConceptGenerator(nn.Module):
    def __init__(self, d=128, hops=3, grounded=True, K=32, vq_levels=2):
        super().__init__()
        self.d, self.hops, self.grounded = d, hops, grounded
        self.emb = nn.Embedding(V, d, padding_idx=0)
        self.tenc = nn.Sequential(nn.Linear(d, d), nn.GELU(), nn.Linear(d, d))  # token-wise MLP (fast, CPU-friendly)
        self.vq = ResidualVQLayer(d, K, vq_levels)
        self.hop_q = nn.ModuleList([nn.Linear(2 * d, d) for _ in range(hops)])
        self.cand = nn.Sequential(nn.Linear(3 * d, d), nn.GELU(), nn.Linear(d, d))
        self.score = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1))
        self.abstain = nn.Sequential(nn.Linear(2 * d, d), nn.GELU(), nn.Linear(d, 1))
        self.route_temp = nn.Parameter(torch.tensor(1.0))
        self.rank_emb = nn.Embedding(64, d)  # positional/rank signal, as any LM sees through position

    def pool(self, x):
        m = (x != 0).float().unsqueeze(-1)
        e = self.emb(x)
        pooled = (e * m).sum(-2) / m.sum(-2).clamp(min=1)
        return pooled + self.tenc(pooled)

    def forward(self, f, perm=None):
        q = self.pool(f["q"].unsqueeze(0))[0]
        P = self.pool(f["p"])
        pid = torch.arange(P.size(0))
        if perm is not None:
            P = P[perm]
        m = P.size(0)
        P = P + self.rank_emb(torch.arange(m).clamp(max=63))
        if self.grounded:
            s, alphas, acc, commit, codes = q, [], torch.zeros(m), 0.0, []
            for h in range(self.hops):
                key = torch.tanh(self.hop_q[h](torch.cat([s, q])))
                a = F.softmax((P @ key) * self.route_temp / self.d ** 0.5, 0)
                alphas.append(a); acc = acc + a
                z, c, cm = self.vq((a @ P).unsqueeze(0))
                s = s + z[0]; commit = commit + cm; codes.append(c[0])
            alpha = (acc / self.hops)
            codes = torch.stack(codes)  # (hops, vq_levels) hierarchical concept codes
        else:  # no concept grounding: flat evidence mean
            s = q + P.mean(0)
            alpha, codes, commit, alphas = torch.full((m,), 1.0 / m), None, torch.zeros(()), []
        cs = self.emb(f["c_span"]).mean(1); cl = self.emb(f["c_left"]).mean(1)
        cp = f["c_pas"]
        if perm is not None:  # candidate passage index in permuted order
            inv = torch.empty_like(perm); inv[perm] = torch.arange(m); cp = torch.where(cp >= 0, inv[cp.clamp(min=0)], cp)
        mass = torch.where(cp >= 0, alpha[cp.clamp(min=0)], torch.ones(len(cp)))
        cand = self.cand(torch.cat([cs, cl, cs * cl], -1)) * (1 + (mass * m).unsqueeze(-1)) if self.grounded \
            else self.cand(torch.cat([cs, cl, cs * cl], -1))
        logits = self.score(torch.cat([cand, s.expand(len(cand), -1)], -1)).squeeze(-1)
        ab = self.abstain(torch.cat([P.mean(0), s], -1))
        return {"logits": torch.cat([logits, ab]), "alpha": alpha, "alphas": alphas, "codes": codes, "commit": commit}


def loss_fn(model, f, lam_cov=1.0, lam_rank=0.5, lam_commit=0.1, rank_invariance=True):
    out = model(f)
    n = len(f["spans"])
    tgt = n if not f["answerable"] else f["target"]  # abstain index = n
    if tgt < 0:
        return None
    L = F.cross_entropy(out["logits"].unsqueeze(0), torch.tensor([tgt]))
    if model.grounded:
        gp = f["gold_pas"]
        if gp.sum() > 0:  # coverage: routing mass should land on every gold passage irrespective of rank
            cov = -(gp / gp.sum() * torch.log(out["alpha"] + 1e-8)).sum()
            L = L + lam_cov * cov
        if rank_invariance:  # rank-invariance: routing must follow identity, not position
            perm = torch.randperm(len(out["alpha"]))
            o2 = model(f, perm=perm)
            a2 = torch.empty_like(o2["alpha"]); a2[perm] = o2["alpha"]
            L = L + lam_rank * F.kl_div((a2 + 1e-8).log(), out["alpha"].detach(), reduction="sum")
        L = L + lam_commit * out["commit"]
    return L


@torch.no_grad()
def predict(model, f):
    model.eval()
    out = model(f)
    i = int(out["logits"].argmax())
    n = len(f["spans"])
    pred = ABSTAIN if i == n else f["spans"][i]
    return pred, out


def train(model, feats, epochs=8, lr=2e-3, seed=0, log=print, **kw):
    torch.manual_seed(seed); random.seed(seed)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    hist = []
    for ep in range(epochs):
        model.train(); random.shuffle(feats); tot, n = 0.0, 0
        for f in feats:
            l = loss_fn(model, f, **kw)
            if l is None:
                continue
            opt.zero_grad(); l.backward(); nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step()
            tot += l.item(); n += 1
        hist.append(tot / max(n, 1)); log(f"epoch {ep+1}/{epochs} loss {hist[-1]:.4f}")
    return hist
