"""GMR-NCM: Grounded Multihop Retrieval for Next-Concept Modeling."""
__version__ = "0.1.0"
