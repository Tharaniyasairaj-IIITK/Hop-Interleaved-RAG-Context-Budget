"""All evaluation metrics from the protocol: EM/F1, claim precision, evidence recall,
hop completion, Top-k claim share, Top-k dependence, positional bias, abstention, efficiency."""
from __future__ import annotations
import numpy as np
from .schema import ABSTAIN
from .text import exact_match, f1_score, normalize_answer


def answer_metrics(pred: str, gold: str):
    return exact_match(pred, gold), f1_score(pred, gold)


def claim_support_table(claims, context, verifier):
    """context: ordered list[Passage] as presented (rank = position+1 in retrieval order).
    Returns per-claim (supported, min_support_rank, all_support_ranks)."""
    rank_of = {p.passage_id: i + 1 for i, p in enumerate(context)}
    rows = []
    for c in claims:
        s = verifier.verify(c, context)
        ranks = sorted(rank_of[p] for p in s.passage_ids)
        rows.append({"claim": c, "supported": s.supported, "ranks": ranks, "min_rank": ranks[0] if ranks else None})
    return rows


def claim_precision(rows):
    return float(np.mean([r["supported"] for r in rows])) if rows else float("nan")


def topk_claim_share(rows, k: int):
    """|{c: r(c)<=k}| / |{c: r(c) exists}|  (paper Eq. for Top-k Claim Share)."""
    have = [r for r in rows if r["min_rank"] is not None]
    return float(np.mean([r["min_rank"] <= k for r in have])) if have else float("nan")


def topk_dependence(rows, k: int):
    """Fraction of supported claims whose supporting passages are *all* within the top-k."""
    have = [r for r in rows if r["ranks"]]
    return float(np.mean([max(r["ranks"]) <= k for r in have])) if have else float("nan")


def excess_topk(rows, gold_ranks, k: int):
    """Top-k dependence minus the share an oracle using exactly the gold evidence would have:
    positive => the model leans on top-ranked passages more than the evidence requires."""
    base = [r <= k for r in gold_ranks]
    d = topk_dependence(rows, k)
    return d - float(np.mean(base)) if base and d == d else float("nan")


def evidence_recall(gold_titles, used_titles):
    g = set(gold_titles)
    return len(g & set(used_titles)) / len(g) if g else float("nan")


def hop_completion(gold_titles, cited_titles):
    return float(set(gold_titles) <= set(cited_titles))


def abstention_correct(pred: str, answerable: bool) -> float:
    return float((pred.strip() == ABSTAIN) == (not answerable))


def gold_position_accuracy(records, n_bins=3):
    """records: list of dicts with 'em' and 'gold_positions' (0-based positions of gold passages in context).
    Bins by mean gold position; returns EM per bin (positional-bias curve)."""
    pos = np.array([np.mean(r["gold_positions"]) / max(1, r["context_len"] - 1) for r in records if r["gold_positions"]])
    em = np.array([r["em"] for r in records if r["gold_positions"]])
    if len(pos) == 0:
        return []
    edges = np.linspace(0, 1, n_bins + 1)
    out = []
    for i in range(n_bins):
        m = (pos >= edges[i]) & ((pos < edges[i + 1]) if i < n_bins - 1 else (pos <= edges[i + 1]))
        out.append(float(em[m].mean()) if m.any() else float("nan"))
    return out


def bootstrap_ci(x, n=1000, seed=0, alpha=0.05):
    x = np.asarray([v for v in x if v == v], dtype=float)
    if len(x) == 0:
        return (float("nan"),) * 2
    rng = np.random.default_rng(seed)
    means = np.array([rng.choice(x, len(x)).mean() for _ in range(n)])
    return float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


def aggregate(per_example: list[dict]) -> dict:
    keys = ["em", "f1", "claim_precision", "evidence_recall", "hop_completion", "top5_claim_share",
            "top5_dependence", "top5_excess_dep", "abstention_acc", "latency_ms", "tokens_generated"]
    out = {}
    for k in keys:
        v = [r[k] for r in per_example if k in r and r[k] == r[k]]
        out[k] = float(np.mean(v)) if v else float("nan")
        if k in {"em", "f1", "claim_precision"} and v:
            out[k + "_ci95"] = bootstrap_ci(v)
    out["n"] = len(per_example)
    return out
