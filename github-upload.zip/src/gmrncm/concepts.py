"""Multiscale residual vector quantisation over text embeddings.

NCM's official tokenizer is a multiscale residual VQ; here we provide a small numpy analogue used to
(i) derive *coarse concept codes* for questions / evidence for logging, and
(ii) define evidence-grounded concept states. The official tokenizer can replace it via ncm_wrapper."""
from __future__ import annotations
import hashlib
import numpy as np
from .text import tokenize


class HashEmbedder:
    """Deterministic hashed bag-of-words (+bigram) embedder; no downloads required."""

    def __init__(self, dim: int = 256, seed: int = 0):
        self.dim, self.seed = dim, seed

    def _h(self, tok: str):
        d = hashlib.md5(f"{self.seed}|{tok}".encode()).digest()
        return int.from_bytes(d[:4], "little") % self.dim, 1.0 if d[4] & 1 else -1.0

    def encode(self, text: str) -> np.ndarray:
        toks = tokenize(text)
        v = np.zeros(self.dim, dtype=np.float32)
        for t in toks + [a + "_" + b for a, b in zip(toks, toks[1:])]:
            i, s = self._h(t)
            v[i] += s
        n = np.linalg.norm(v)
        return v / n if n else v

    def encode_many(self, texts):
        return np.stack([self.encode(t) for t in texts]) if texts else np.zeros((0, self.dim), np.float32)


class ResidualVQ:
    """L-level residual VQ trained by k-means; levels go coarse -> fine."""

    def __init__(self, levels: int = 3, codebook_size: int = 32, seed: int = 0):
        self.L, self.K, self.seed = levels, codebook_size, seed
        self.codebooks: list[np.ndarray] = []

    def fit(self, X: np.ndarray, iters: int = 15):
        rng = np.random.default_rng(self.seed)
        R = X.copy()
        self.codebooks = []
        for _ in range(self.L):
            K = min(self.K, len(R))
            C = R[rng.choice(len(R), K, replace=False)].copy()
            for _ in range(iters):
                a = ((R[:, None, :] - C[None]) ** 2).sum(-1).argmin(1)
                for k in range(K):
                    m = a == k
                    if m.any():
                        C[k] = R[m].mean(0)
            self.codebooks.append(C)
            R = R - C[((R[:, None, :] - C[None]) ** 2).sum(-1).argmin(1)]
        return self

    def encode(self, X: np.ndarray) -> np.ndarray:
        R, codes = X.copy(), []
        for C in self.codebooks:
            a = ((R[:, None, :] - C[None]) ** 2).sum(-1).argmin(1)
            codes.append(a); R = R - C[a]
        return np.stack(codes, 1)  # (N, L)

    def decode(self, codes: np.ndarray, upto: int | None = None) -> np.ndarray:
        L = upto or self.L
        return sum(self.codebooks[l][codes[:, l]] for l in range(L))
