"""Tokenisation, answer normalisation, claim splitting."""
from __future__ import annotations
import re, string, collections

_STOP = set("a an the of in on at to for and or is was were are be been by with from as that this which who whom whose what when where how did does do it its their his her than then".split())
_TOK = re.compile(r"[A-Za-z0-9]+")


def tokenize(s: str) -> list[str]:
    return [t.lower() for t in _TOK.findall(s)]


def content_tokens(s: str) -> list[str]:
    return [t for t in tokenize(s) if t not in _STOP]


def normalize_answer(s: str) -> str:
    s = s.lower()
    s = "".join(ch for ch in s if ch not in set(string.punctuation))
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def exact_match(pred: str, gold: str) -> float:
    return float(normalize_answer(pred) == normalize_answer(gold))


def f1_score(pred: str, gold: str) -> float:
    p, g = normalize_answer(pred).split(), normalize_answer(gold).split()
    if not p or not g:
        return float(p == g)
    common = collections.Counter(p) & collections.Counter(g)
    n = sum(common.values())
    if n == 0:
        return 0.0
    pr, rc = n / len(p), n / len(g)
    return 2 * pr * rc / (pr + rc)


def split_sentences(text: str) -> list[str]:
    parts = re.split(r"(?<=[.!?])\s+", text.strip())
    return [p for p in parts if p]
