"""Unified example / passage schema and JSONL helpers (matches the data-prep spec)."""
from __future__ import annotations
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable, Iterator


@dataclass
class Passage:
    passage_id: str
    title: str
    text: str
    doc_id: str = ""
    url: str = ""
    revision_date: str = ""


@dataclass
class Example:
    id: str
    source_dataset: str
    question: str
    gold_answer: str
    answer_type: str = "span"  # span | yesno | entity
    num_hops: int = 2
    gold_supporting_facts: list = field(default_factory=list)  # [{"title":..,"sent_id":..}]
    gold_passage_titles: list = field(default_factory=list)
    distractor_passage_titles: list = field(default_factory=list)
    answerable: bool = True  # False => gold behaviour is INSUFFICIENT_EVIDENCE
    metadata: dict = field(default_factory=dict)


ABSTAIN = "INSUFFICIENT_EVIDENCE"


def write_jsonl(path: str | Path, rows: Iterable) -> int:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    n = 0
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            if hasattr(r, "__dataclass_fields__"):
                r = asdict(r)
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
            n += 1
    return n


def read_jsonl(path: str | Path) -> Iterator[dict]:
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                yield json.loads(line)


def load_examples(path) -> list[Example]:
    return [Example(**r) for r in read_jsonl(path)]


def load_passages(path) -> list[Passage]:
    return [Passage(**r) for r in read_jsonl(path)]
