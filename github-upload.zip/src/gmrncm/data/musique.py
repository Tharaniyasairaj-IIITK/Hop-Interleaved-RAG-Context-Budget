"""MuSiQue (official JSONL format, see StonyBrookNLP/musique raw_data_to_official_format.py) -> unified schema.
Record: {id, question, question_decomposition[{question,answer,paragraph_support_idx}], answerable, answer,
         answer_aliases, paragraphs[{idx,title,paragraph_text,is_supporting}]}.
MuSiQue-Full contains answerable=False records -> natural abstention (INSUFFICIENT_EVIDENCE) examples."""
from __future__ import annotations
import json, re
from ..schema import Example, Passage


def convert_musique(path: str, split: str, limit: int | None = None):
    examples, passages = [], {}
    for n, line in enumerate(open(path, encoding="utf-8")):
        if limit and n >= limit:
            break
        r = json.loads(line)
        gold_titles, dist_titles = [], []
        for p in r["paragraphs"]:
            pid = f"musique:{r['id']}::{p['idx']}"
            passages[pid] = Passage(pid, p["title"], p["paragraph_text"], doc_id=f"musique:{r['id']}")
            (gold_titles if p["is_supporting"] else dist_titles).append(p["title"])
        m = re.match(r"(\d)hop", r["id"])
        hops = int(m.group(1)) if m else max(2, len(r.get("question_decomposition", [])))
        ans = r["answer"] if r.get("answerable", True) else ""
        examples.append(Example(
            id=f"musique_{split}_{r['id']}", source_dataset="musique", question=r["question"], gold_answer=ans,
            answer_type="span", num_hops=hops,
            gold_supporting_facts=[{"title": p["title"], "sent_id": -1} for p in r["paragraphs"] if p["is_supporting"]],
            gold_passage_titles=list(dict.fromkeys(gold_titles)), distractor_passage_titles=dist_titles,
            answerable=bool(r.get("answerable", True)),
            metadata={"answer_aliases": r.get("answer_aliases", []),
                      "decomposition": [d["question"] for d in r.get("question_decomposition", [])]}))
    return examples, list(passages.values())
