"""Real multihop data: the 1,000-question HotpotQA / 2WikiMultihopQA / MuSiQue development subsets and their
retrieval corpora as redistributed (MIT) in the OSU-NLP-Group/HippoRAG repository (reproduce/dataset/).
The same subsets are used by the HippoRAG paper, so retrieval recall is directly comparable with its tables.
Original data licences apply (HotpotQA CC BY-SA 4.0, MuSiQue CC BY 4.0, 2WikiMultihopQA Apache-2.0)."""
from __future__ import annotations
import json
from pathlib import Path
from ..schema import Example, Passage

FILES = {"hotpotqa": "hotpotqa", "2wiki": "2wikimultihopqa", "musique": "musique"}


def _unique_keys(corpus):
    """Passage keys: the title when unique in the corpus, else 'title #i' (MuSiQue repeats titles)."""
    from collections import Counter
    c = Counter(p["title"] for p in corpus)
    return [p["title"] if c[p["title"]] == 1 else f"{p['title']} #{i}" for i, p in enumerate(corpus)]


def load_hippo_subset(name: str, root: str, limit: int | None = None):
    base = FILES[name]
    data = json.load(open(Path(root) / f"{base}.json", encoding="utf-8"))
    corpus = json.load(open(Path(root) / f"{base}_corpus.json", encoding="utf-8"))
    keys = _unique_keys(corpus)
    passages = [Passage(f"{name}:{i}", keys[i], p["text"], doc_id=f"{name}:{i}") for i, p in enumerate(corpus)]
    by_title = {}
    for ps in passages:
        by_title.setdefault(ps.title.split(" #")[0], []).append(ps)
    by_text = {p["text"]: passages[i] for i, p in enumerate(corpus)}
    if limit:
        data = data[:limit]
    examples = []
    for r in data:
        if name == "musique":
            sup = [p for p in r["paragraphs"] if p["is_supporting"]]
            gold = [by_text[p["paragraph_text"]].title for p in sup]
            qid, hops = r["id"], int(r["id"][0])
            meta = {"type": f"{hops}hop"}
            ans = r["answer"]
        else:
            gt = list(dict.fromkeys(t for t, _ in r["supporting_facts"]))
            gold = [by_title[t][0].title for t in gt]
            qid, hops = r["_id"], max(2, len(gt))
            meta = {"type": r.get("type", "")}
            ans = r["answer"]
        examples.append(Example(
            id=f"{name}_{qid}", source_dataset=name, question=r["question"], gold_answer=ans,
            answer_type="yesno" if ans.lower() in {"yes", "no"} else "span", num_hops=hops,
            gold_passage_titles=gold, answerable=True, metadata=meta))
    return examples, passages
