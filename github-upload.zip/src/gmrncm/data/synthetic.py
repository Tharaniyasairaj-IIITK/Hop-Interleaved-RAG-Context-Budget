"""Synthetic bridge/comparison multihop world used for offline smoke tests and unit tests.
NOT a benchmark: it only validates the pipeline end-to-end without internet access."""
from __future__ import annotations
import random
from ..schema import Example, Passage, ABSTAIN

FIRST = "Alara Borin Cedric Dalia Edric Fenna Goran Halia Ivor Jessa Kellan Lirael Marek Nessa Orin Petra Quill Rhea Soren Talia Ulric Vera Wylan Xena Yorick Zara".split()
LAST = "Ashford Brightwater Caldwell Dunmore Eastwood Fairbanks Gresham Holloway Ingram Jarrow Kestrel Langley Merrick Northcott Ormsby Pembroke Quarles Rowntree Stanhope Thorne".split()
CITY = "Arvenport Belmora Cindral Dovenham Elmridge Farrowick Glenmoor Havenbrook Ironvale Jasperton".split()
FILM = "Silent Harbor|Crimson Tide Road|Paper Lanterns|The Last Orchard|Winter Signal|Glass Meridian|Hollow Crown|Midnight Ferry|Copper Skies|Northern Lights Club".split("|")


def build_world(n_questions: int = 200, seed: int = 0, n_noise: int = 400, abstain_frac: float = 0.1,
                kinds=("bridge", "bridge3")):
    rng = random.Random(seed)
    people, passages, examples = {}, {}, []
    used = set()

    def person():
        for _ in range(200):
            n = f"{rng.choice(FIRST)} {rng.choice(LAST)}"
            if n not in used:
                used.add(n); return n
        while True:  # pool exhausted -> disambiguate with a numeric suffix (avoids an infinite loop)
            n = f"{rng.choice(FIRST)} {rng.choice(LAST)} {len(used)}"
            if n not in used:
                used.add(n); return n

    def add(title, text):
        pid = f"wiki:{title.replace(' ', '_')}::0000"
        passages[pid] = Passage(pid, title, text, doc_id=f"wiki:{title.replace(' ', '_')}")
        return pid

    for i in range(n_questions):
        kind = rng.choice(list(kinds))
        if kind == "bridge":
            film = f"{rng.choice(FILM)} {i}"
            d = person(); city = f"{rng.choice(CITY)} {i}"
            p1 = add(film, f"{film} is a drama film released in {rng.randint(1950, 2015)}. The film was directed by {d}.")
            p2 = add(d, f"{d} is a film director. {d} was born in {city}.")
            q, a, gold = f"In which city was the director of {film} born?", city, [film, d]
            hops = 2
        elif kind == "bridge3":
            film = f"{rng.choice(FILM)} {i}"
            d = person(); city = f"{rng.choice(CITY)} {i}"; country = f"{rng.choice(LAST)}land {i}"
            add(film, f"{film} is a thriller film. The film was directed by {d}.")
            add(d, f"{d} is a film director. {d} was born in {city}.")
            add(city, f"{city} is a port town. {city} is located in the {country}.")
            q, a, gold = f"In which country was the director of {film} born?", country, [film, d, city]
            hops = 3
        else:
            a1, a2 = person(), person()
            y1, y2 = rng.randint(1930, 1990), rng.randint(1930, 1990)
            while y2 == y1:
                y2 = rng.randint(1930, 1990)
            add(a1, f"{a1} is an actor. {a1} was born in {y1}.")
            add(a2, f"{a2} is an actor. {a2} was born in {y2}.")
            q = f"Who was born first, {a1} or {a2}?"
            a = a1 if y1 < y2 else a2
            gold, hops = [a1, a2], 2
        pid_gold = [f"wiki:{t.replace(' ', '_')}::0000" for t in gold]
        examples.append(Example(id=f"syn_{i:05d}", source_dataset="synthetic", question=q, gold_answer=a,
                                answer_type="entity", num_hops=hops,
                                gold_supporting_facts=[{"title": t, "sent_id": 0} for t in gold],
                                gold_passage_titles=gold, answerable=True,
                                metadata={"requires_comparison": kind == "comparison"}))
    # distractors that look similar (lexical overlap) but are irrelevant
    for j in range(n_noise):
        t = f"{rng.choice(FILM)} {1000 + j}"
        d = person()
        add(t, f"{t} is a drama film. The film was directed by {d}. It was filmed in {rng.choice(CITY)}.")
    # abstention examples: gold passage is removed from the corpus visible to the retriever
    k = int(abstain_frac * len(examples))
    for ex in rng.sample(examples, k):
        ex.answerable = False
        ex.metadata["removed_gold"] = ex.gold_passage_titles[-1]
    removed = {ex.metadata["removed_gold"] for ex in examples if not ex.answerable}
    corpus = [p for p in passages.values() if p.title not in removed]
    return examples, corpus
