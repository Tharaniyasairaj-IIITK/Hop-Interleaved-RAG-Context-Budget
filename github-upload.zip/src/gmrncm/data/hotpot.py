"""Convert HotpotQA (distractor setting) into the unified schema + a deduplicated passage corpus.
Download: see scripts/download_assets.sh. Works on hotpot_{train,dev_distractor}_v1.json."""
from __future__ import annotations
import json
from ..schema import Example, Passage


def convert_hotpot(path: str, split: str, limit: int | None = None, source: str = "hotpotqa"):
    data = json.load(open(path, encoding="utf-8"))
    if limit:
        data = data[:limit]
    examples, passages = [], {}
    for r in data:
        for title, sents in r["context"]:
            pid = f"wiki:{title.replace(' ', '_')}::0000"
            passages.setdefault(pid, Passage(pid, title, " ".join(s.strip() for s in sents), doc_id=pid.split("::")[0]))
        gold = list(dict.fromkeys(t for t, _ in r["supporting_facts"]))
        ans = r["answer"]
        examples.append(Example(
            id=f"{source}_{split}_{r['_id']}", source_dataset=source, question=r["question"], gold_answer=ans,
            answer_type="yesno" if ans.lower() in {"yes", "no"} else "span", num_hops=max(2, len(r.get("evidences", [])) or 2),
            gold_supporting_facts=[{"title": t, "sent_id": s} for t, s in r["supporting_facts"]],
            gold_passage_titles=gold,
            distractor_passage_titles=[t for t, _ in r["context"] if t not in gold],
            metadata={"requires_comparison": r.get("type") == "comparison", "level": r.get("level", ""), "type": r.get("type", "")}))
    return examples, list(passages.values())


def convert_2wiki(path: str, split: str, limit: int | None = None):
    """2WikiMultihopQA uses the HotpotQA fields (+ evidences triples, type in {comparison, inference,
    compositional, bridge_comparison}); num_hops = number of evidence triples."""
    return convert_hotpot(path, split, limit, source="2wiki")
