"""[Superseded by ncm_official.py, which is verified against the official code.]
Adapter to the official Hazy Research NCM release (https://github.com/HazyResearch/ncm).

IMPORTANT: this adapter defines the *interface* GMR-NCM needs; it could not be tested against the official
code in the authoring environment (no network access to the repository/checkpoints). Fill the three
`_official_*` hooks after reading the repository's evaluate.py / tokenizer / generator classes.

Required capabilities
  1. tokenizer.encode(text) -> (L, T_l) hierarchical code grids; tokenizer.decode(codes) -> text
  2. generator.sample(prefix_codes, cond) -> coarse-to-fine code grids, positions in parallel per level
  3. a conditioning path for evidence: (a) prefix serialisation (zero new parameters), or
     (b) cross-attention adapter / LoRA (see `EvidenceAdapter`).
"""
from __future__ import annotations
from dataclasses import dataclass


@dataclass
class NCMHandle:
    tokenizer: object
    generator: object
    config: dict


def load_official_ncm(checkpoint_dir: str, config_yaml: str) -> NCMHandle:  # pragma: no cover
    raise NotImplementedError(
        "Import the official NCM classes here, e.g. add the cloned repo to PYTHONPATH and construct the "
        "tokenizer/generator from config.yaml + *.pt in `checkpoint_dir`. See scripts/reproduce_ncm_baseline.sh.")


def serialize_prompt(question: str, context, instructions: bool = True) -> str:
    """Identical prompt template for all systems (Section 7 of the data-prep spec)."""
    ev = "\n\n".join(f"[{i+1}] Title: {p.title}\n{p.text}" for i, p in enumerate(context))
    s = f"Question: {question}\n\nEvidence:\n{ev}\n"
    if instructions:
        s += ("\nInstructions:\nUse only the provided evidence.\nIf the evidence is insufficient, answer "
              '"INSUFFICIENT_EVIDENCE".\nFirst identify the required reasoning steps.\nThen provide the final answer.')
    return s


class EvidenceAdapter:  # pragma: no cover - requires torch + official generator
    """Cross-attention adapter inserted after the generator's self-attention blocks.
    Keys/values: evidence-token states tagged with (source-id, hop, rank-invariant) embeddings;
    queries: concept-state positions at each level. Initialised to identity (zero-init gate)."""

    def __init__(self, d_model: int, n_heads: int = 8, n_sources: int = 64, n_hops: int = 4):
        import torch.nn as nn, torch
        self.attn = nn.MultiheadAttention(d_model, n_heads, batch_first=True)
        self.src = nn.Embedding(n_sources, d_model)
        self.hop = nn.Embedding(n_hops, d_model)
        self.gate = nn.Parameter(torch.zeros(1))
