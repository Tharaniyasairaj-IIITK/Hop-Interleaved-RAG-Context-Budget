"""Readers for the pickle files released by the Stanford Hazy Research NCM release
(Hugging Face dataset `hazyresearch/ncm-datasets`; e.g. xsum/passages.pickle, xsum/reference_summaries.pickle).

How the official evaluation reads them (scripts/eval_shard.py): `pickle.load(open(path,'rb'))[:n]`, giving a list whose
items are raw strings (XSum/WMT passages, tokenised on the fly with the GPT-2 tokenizer) or pre-tokenised id lists;
references are a parallel list (asserted equal length).

SECURITY: unpickling untrusted data can execute arbitrary code. We therefore load with a restricted unpickler that
only allows plain builtin containers/scalars, so a tampered file fails closed instead of running code.

Roles in this paper (see Sec. 'Released assets'):
  R1  reproduction gate: official XSum evaluation on passages.pickle + reference_summaries.pickle before any change;
  R2  natural-text distractor pool for the noise-robustness study (`xsum_distractors`).
Status in the packaged results: the files could NOT be downloaded in the authoring sandbox, so neither role is
reflected in any reported number; the loaders are tested on stand-in files with the same structure."""
from __future__ import annotations
import io, pickle, hashlib
from pathlib import Path
from .schema import Passage

_ALLOWED = {("builtins", n) for n in ("list", "tuple", "dict", "set", "frozenset", "str", "int", "float", "bool", "bytes")}


class _Restricted(pickle.Unpickler):
    def find_class(self, module, name):
        if (module, name) in _ALLOWED:
            return super().find_class(module, name)
        raise pickle.UnpicklingError(f"blocked global {module}.{name}")


def load_pickle_safe(path: str | Path):
    with open(path, "rb") as f:
        return _Restricted(io.BytesIO(f.read())).load()


def sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def inspect_pickle(path: str | Path) -> dict:
    obj = load_pickle_safe(path)
    if not isinstance(obj, (list, tuple)):
        return {"path": str(path), "type": type(obj).__name__, "sha256": sha256(path)}
    first = obj[0] if obj else None
    kind = "str" if isinstance(first, str) else "token_ids" if isinstance(first, (list, tuple)) else type(first).__name__
    lens = [len(x.split()) if isinstance(x, str) else len(x) for x in obj[:2000]]
    return {"path": str(path), "n": len(obj), "item_kind": kind, "sha256": sha256(path),
            "len_unit": "words" if kind == "str" else "tokens",
            "len_mean": sum(lens) / max(1, len(lens)), "len_max": max(lens) if lens else 0}


def load_xsum_pair(passages_pickle, refs_pickle, n: int | None = None):
    items, refs = load_pickle_safe(passages_pickle), load_pickle_safe(refs_pickle)
    if n:
        items, refs = items[:n], refs[:n]
    assert len(items) == len(refs), f"{len(items)} inputs vs {len(refs)} references (official eval asserts equality)"
    return items, refs


def xsum_distractors(passages_pickle, n: int, max_words: int = 150, start: int = 0) -> list[Passage]:
    """Turn released XSum articles into retrieval distractors (natural news text, topically unrelated to the
    synthetic/Wikipedia questions). Requires string items; pre-tokenised variants must be decoded first."""
    items = load_pickle_safe(passages_pickle)[start:start + n]
    out = []
    for i, t in enumerate(items):
        if not isinstance(t, str):
            raise TypeError("expected raw-string passages; decode token ids with the GPT-2 tokenizer first")
        w = t.split()
        out.append(Passage(f"xsum:{start+i}", " ".join(w[:6]), " ".join(w[:max_words]), doc_id=f"xsum:{start+i}"))
    return out
