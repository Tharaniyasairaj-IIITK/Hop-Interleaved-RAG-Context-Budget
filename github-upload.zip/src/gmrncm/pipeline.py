"""End-to-end offline pipeline on the synthetic multihop world (pipeline validation, NOT a benchmark).
The same functions run on HotpotQA/2Wiki/MuSiQue once converted to the unified schema."""
from __future__ import annotations
import json, random
from pathlib import Path
import numpy as np
from .schema import write_jsonl
from .retrieval import BM25Retriever
from .multihop import IterativeRetriever
from .grounding import ground_context
from .data.synthetic import build_world
from .systems import SystemSpec, evaluate_system
from .baselines import MajorityPrior, NeuralPredictor
from . import metrics as M

SPECS = {
    "closed_book":        SystemSpec("closed_book", "closed_book"),
    "ref_top5":           SystemSpec("ref_top5", "top_k", grounded=False),
    "ref_multihop5":      SystemSpec("ref_multihop5 (no concept grounding)", "multihop", grounded=False),
    "gmr_noiter":         SystemSpec("gmr_noiter (no iterative retrieval)", "top_k", grounded=True, verify=True),
    "gmr_noverify":       SystemSpec("gmr_noverify", "multihop", grounded=True, verify=False),
    "gmr_norankinv":      SystemSpec("gmr_norankinv", "multihop", grounded=True, verify=True),
    "gmr_full":           SystemSpec("GMR-NCM (full)", "multihop", grounded=True, verify=True),
}


def build_traces(examples, corpus, hops=3, per_hop_k=10):
    r = BM25Retriever(corpus)
    it = IterativeRetriever(r, corpus, hops=hops, per_hop_k=per_hop_k)
    return {e.id: it.run(e.id, e.question).to_dict() for e in examples}, {p.passage_id: p for p in corpus}


def split(examples, seed=0, frac=(0.6, 0.1, 0.3)):
    ex = examples[:]; random.Random(seed).shuffle(ex)
    a, b = int(frac[0] * len(ex)), int((frac[0] + frac[1]) * len(ex))
    return ex[:a], ex[a:b], ex[b:]


def make_features(examples, traces, by_id, mode, budget, shuffle_ctx=False, seed=0):
    from .model import featurize
    rng = random.Random(seed); feats = []
    for ex in examples:
        ctx = ground_context(traces[ex.id], by_id, budget, mode=mode)
        if shuffle_ctx:
            rng.shuffle(ctx)
        feats.append(featurize(ex.question, ctx, ex.gold_passage_titles, ex.gold_answer, ex.answerable))
    return feats


def run_all(n_questions=300, seed=0, budget=5, epochs=6, out_dir="results/runs/smoke", log=print, systems=None):
    import torch
    from .model import GMRConceptGenerator, train
    examples, corpus = build_world(n_questions, seed=seed)
    tr_ex, dv_ex, te_ex = split(examples, seed)
    traces, by_id = build_traces(examples, corpus)
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    for ex in te_ex:
        Path(out_dir, "retrieval_traces").mkdir(exist_ok=True)
        json.dump(traces[ex.id], open(Path(out_dir, "retrieval_traces", f"{ex.id}.json"), "w"))
    results, rows_all = {}, {}
    systems = systems or list(SPECS)
    for key in systems:
        spec = SPECS[key]
        if key == "closed_book":
            pred = MajorityPrior(tr_ex)
        else:
            torch.manual_seed(seed)
            model = GMRConceptGenerator(grounded=spec.grounded, hops=3)
            feats = make_features(tr_ex, traces, by_id, spec.context_mode, budget)
            kw = dict(rank_invariance=(key != "gmr_norankinv"), lam_cov=1.0 if spec.grounded else 0.0)
            train(model, feats, epochs=epochs, seed=seed, log=lambda s: None, **kw)
            pred = NeuralPredictor(model)
        rows = evaluate_system(spec, te_ex, traces, by_id, pred, budget=budget)
        results[key] = M.aggregate(rows); rows_all[key] = rows
        log(f"{key:14s} EM={results[key]['em']:.3f} F1={results[key]['f1']:.3f} "
            f"ER={results[key]['evidence_recall']:.3f} HC={results[key]['hop_completion']:.3f}")
    return results, rows_all, dict(tr=tr_ex, dv=dv_ex, te=te_ex, traces=traces, by_id=by_id, corpus=corpus)


# ---------------------------------------------------------------------------------------------------------------
def topk_from_rows(rows_by_sys: dict, info: dict, budget: int, k: int = 3):
    """Dep_k / Share_k / excess dependence recomputed with k < B (at k = B they are trivially 1)."""
    from .verifier import LexicalVerifier
    ver, exm, out = LexicalVerifier(), {e.id: e for e in info["te"]}, {}
    for name, rows in rows_by_sys.items():
        mode = "top_k" if name in {"ref_top5", "gmr_noiter"} else "multihop"
        sh, dp, ex_ = [], [], []
        for r in rows:
            if name == "closed_book" or not r["generated_reasoning"]:
                continue
            e = exm[r["id"]]
            ctx = ground_context(info["traces"][e.id], info["by_id"], budget, mode=mode)
            tab = M.claim_support_table(r["generated_reasoning"], ctx, ver)
            gr = [i + 1 for i, p in enumerate(ctx) if p.title in set(e.gold_passage_titles)]
            sh.append(M.topk_claim_share(tab, k)); dp.append(M.topk_dependence(tab, k))
            ex_.append(M.excess_topk(tab, gr, k) if gr else float("nan"))
        f = lambda v: float(np.nanmean(v)) if len(v) else float("nan")
        out[name] = {"share_k": f(sh), "dep_k": f(dp), "excess_dep_k": f(ex_)}
    return out


def _suite_one_seed(args):
    seed, n_questions, epochs, budget, k = args
    import torch
    torch.set_num_threads(1)
    res, rows, info = run_all(n_questions, seed, budget, epochs, out_dir=f"results/runs/suite_s{seed}", log=lambda s: None)
    tk = topk_from_rows(rows, info, budget, k)
    out = {}
    for name in res:
        r = rows[name]
        ans = [x["em"] for x in r if x["answerable"]]
        una = [x["abstention_acc"] for x in r if not x["answerable"]]
        out[name] = {**{m: res[name][m] for m in ("em", "f1", "claim_precision", "evidence_recall", "hop_completion", "abstention_acc", "latency_ms")},
                     "em_answerable": float(np.mean(ans)), "abstain_recall": float(np.mean(una)) if una else float("nan"),
                     "n_test": len(r), "n_unanswerable": len(una), **tk[name]}
    return seed, out


def run_suite(seeds=(0, 1, 2, 3, 4), n_questions=200, epochs=5, budget=5, k=3, workers=2, out="results/notebook_suite.json"):
    """All systems and ablations x several seeds (parallel over seeds); saves one JSON that feeds Tables 2-3."""
    import json
    from concurrent.futures import ProcessPoolExecutor
    with ProcessPoolExecutor(workers) as ex:
        res = dict(ex.map(_suite_one_seed, [(s, n_questions, epochs, budget, k) for s in seeds]))
    cfg = dict(seeds=list(seeds), n_questions=n_questions, epochs=epochs, budget=budget, k=k)
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    json.dump({"config": cfg, "per_seed": {str(s): v for s, v in res.items()}}, open(out, "w"), indent=1, default=float)
    return cfg, res
