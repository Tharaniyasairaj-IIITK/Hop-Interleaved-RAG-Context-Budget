"""Claim-level evidence verification. Default: lexical/entity support score (offline).
Plug an NLI model through `NLIVerifier` for full experiments."""
from __future__ import annotations
from dataclasses import dataclass
from .text import content_tokens, split_sentences


@dataclass
class Support:
    supported: bool
    score: float
    passage_ids: list  # passages that individually support the claim


class LexicalVerifier:
    def __init__(self, tau: float = 0.8):
        self.tau = tau

    def score(self, claim: str, passage_text: str) -> float:
        ct = set(content_tokens(claim))
        if not ct:
            return 0.0
        pt = set(content_tokens(passage_text))
        return len(ct & pt) / len(ct)

    def verify(self, claim: str, passages: list) -> Support:
        """passages: list[Passage]; returns every passage whose sentence-level support >= tau."""
        sup, best = [], 0.0
        for p in passages:
            s = max([self.score(claim, sent) for sent in split_sentences(p.text)] + [self.score(claim, p.text) * 0.9])
            best = max(best, s)
            if s >= self.tau:
                sup.append(p.passage_id)
        return Support(bool(sup), best, sup)


class NLIVerifier:
    """HF NLI/entailment verifier, e.g. 'microsoft/deberta-large-mnli'."""

    def __init__(self, model="microsoft/deberta-large-mnli", tau=0.5, device=-1):
        from transformers import pipeline
        self.pipe = pipeline("text-classification", model=model, device=device, top_k=None)
        self.tau = tau

    def verify(self, claim, passages):
        sup, best = [], 0.0
        for p in passages:
            out = self.pipe({"text": p.text, "text_pair": claim})[0]
            ent = next(o["score"] for o in out if o["label"].lower().startswith("entail"))
            best = max(best, ent)
            if ent >= self.tau:
                sup.append(p.passage_id)
        return Support(bool(sup), best, sup)
